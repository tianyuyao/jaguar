#include  <stdio.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <string.h>
///////////// include C header files /////////////////////
#ifdef __cplusplus
extern "C" {
#endif
#include <adbclient.h>
#ifdef __cplusplus
}
#endif
//////////////////////////////////////////////////////////


int main( int argc, char *argv[] )
{
    const char username[]="test";
    const char passwd[]="test";
    const char dbname[]="test";
	const char  *unixSocket = NULL;
    short port = 8888;
    ADB *adb;
	int rc;
    
    
    adb = adbInit();
    if ( adb == NULL) {
        printf( "Error adbInit, exit\n"); 
        exit(1);
    }
    
    if ( ! adbConnect( adb, "127.0.0.1", port, username, passwd, dbname, unixSocket, 0 ) ) {
        printf( "Error connect\n");
        adbClose( adb );
        exit(1);
    }
    
	char  query[1024];
	memset( query, 0, 1024 );
	sprintf( query, "insert into user ( [uid='larryz', zip='99842'], [ city='danville', wechat='larryzx' ] )" );
    rc = adbQuery( adb, query ); 
	if ( ! rc ) {
        printf( "Error adbQuery insert\n");
        adbClose( adb );
        exit(1);
	}

	ADBROW     row; 
	sprintf( query, "select * from user");
	rc = adbQuery( adb, query );
	if ( ! rc ) {
        printf( "Error adbQuery select [%s]\n", adb->errmsg );
        adbClose( adb );
        exit(1);
	}

	adbInitRow( adb, &row );
    while ( adbReply( &row ) ) {
		char *value = adbGetValue( &row, "uid");
		printf("uid='%s' ", value );
		free( value );

		value = adbGetValue(&row, "test.user.zip");
		printf("zip='%s' ", value );
		free( value );

		printf("\n"); 
    }

	if ( adbHasError( &row ) ) {
		printf("Error: %s\n", adbError( &row ) );
	}
	adbFreeRow( &row );

    adbClose( adb );
}

