
LIBPATH=$HOME/jaguar/lib

javac -cp $LIBPATH/jaguar-jdbc-2.0.jar  MetadataTest.java
java -Djava.library.path=$LIBPATH -cp $LIBPATH/jaguar-jdbc-2.0.jar:. MetadataTest

g++ -I$HOME/jaguuar/include -o example example.cc $HOME/jaguar/lib/libjaguar.a -lz
