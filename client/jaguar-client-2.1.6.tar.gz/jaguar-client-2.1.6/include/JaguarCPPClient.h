#ifndef _jaguar_cpp_client_h_
#define _jaguar_cpp_client_h_

#define RAY_SOCK_MSG_HDR_LEN  10
#define RAY_ERR_MSG_LEN  256
#define RAY_MAX_NUM_KEYS  256
#define RAY_COL_MAX 512
#define RAY_NAME_MAX 64 
#define RAY_SESSIONID_MAX 32


#ifdef _WINDOWS64_
#include<winsock2.h> 
#include <stdio.h>

#ifdef EXPORT_DLL
#define LIB_API __declspec(dllexport)
#else
#define LIB_API
#endif

#else
#define LIB_API
#endif

#include <abax.h>
#include <rayhashtable.h>
#include <AbaxStrSplitWithQuote.h>
#include <AbaxSimpleVector.h>


class RayReadWriteLock;
class RayRecord;


class RayKeyValProp {
  public:
	char  dbname[RAY_NAME_MAX];
	char  tabname[RAY_NAME_MAX];
	char  colname[RAY_NAME_MAX];
	int 	offset;
	int 	length;
	char 	type;
	int  	sig;
	bool    iskey;

	RayKeyValProp(){}
	RayKeyValProp( const RayKeyValProp &s2 ) {
		strcpy( dbname, s2.dbname );
		strcpy( tabname, s2.tabname );
		strcpy( colname, s2.colname );
		offset = s2.offset;
		length = s2.length;
		type = s2.type;
		sig = s2.sig;
		iskey = s2.iskey;
	}

	RayKeyValProp& operator=( const RayKeyValProp &s2 ) {
		if ( colname == s2.colname ) return *this;
		strcpy( dbname, s2.dbname );
		strcpy( tabname, s2.tabname );
		strcpy( colname, s2.colname );
		offset = s2.offset;
		length = s2.length;
		type = s2.type;
		sig = s2.sig;
		iskey = s2.iskey;
		return * this;
	}
};

class RayTabSchema {
  public:
  	RayTabSchema() {}
  	RayTabSchema( const RayTabSchema &s2 ) {
		strcpy( dbtab, s2.dbtab );
		kvlen = s2.kvlen;
	}

	RayTabSchema& operator= ( const RayTabSchema &s2 ) {
		if ( dbtab == s2.dbtab ) return *this;
		strcpy( dbtab, s2.dbtab );
		kvlen = s2.kvlen;
		return *this;
	}

	char  dbtab[2*RAY_NAME_MAX];
	int 	kvlen;
};

struct  _RAYCLOCK
{
 	int  beginsec, beginmsec, beginusec;
   	int  endsec, endmsec, endusec;
};

struct  _ADB
{
#ifdef _WINDOWS64_
	SOCKET socket;
#else
	int 	socket;
#endif
    
	char  	errmsg[RAY_ERR_MSG_LEN];
	char  	dbname[RAY_NAME_MAX];
	char    *query;
	char  	session[RAY_SESSIONID_MAX];
};
typedef struct _ADB  ADB;

struct _ADBROW
{
	int    retCode;
	// char   *hdr;
	bool hasSchema;
	char   *data;
	char   type;
	FILE   *outf;
	
	// RaySchemaProp prop[RAY_MAX_NUM_KEYS];
	// int    numKeys;
	// int    keyLength;
	// int    valueLength;

	char 	*g_names[1024];
	char 	*g_values[1024];
	ray_hash_t  colHash;

	int		isMeta;
	int		colCount;

	ADB    *adb;
	void   *etc;
	//AbaxStrSplitWithQuote *qsplit;
	//int		qcmdnum;
	//int		qcmdpos;

	RayKeyValProp prop[RAY_COL_MAX];
	int    numKeyVals;
};
typedef struct _ADBROW  ADBROW;


class LIB_API JaguarCPPClient 
{
  public:
  	JaguarCPPClient();
	~JaguarCPPClient();
	void destroy();

	// 0: error  1: OK   adb->sock = socket() ....
	// send username and password to socket. Server verifies and sends authentication
	// info back from server. OK: 1  error: 0
	int connect( const char *ipaddress, unsigned int port, 
				const char *username, const char *passwd,
				const char *dbname, const char *unixSocket,
				unsigned long clientFlag );

    // send command to socket to server
    // 1: OK   0: error
    int query( const char *query, bool reply=true );   // send query command over sock to server in adb object

    // server sends number of columns in the result over socket
    // client receives a row
    // 0: error or reaching the last record
    // 1: successful and having more records
    int reply( bool headerOnly = false );

	int sendFile( const char *loadCommand );

	// get session string
	const char *getSession();

	// set Op
	// void setOp( char op );

	// get session string
	const char *getDatabase();

    // client receives a row
    int printRow( FILE *outf );

    // get n-th column in the row
    // NULL if not found; malloced char* if found, must be freed later
    char *getNthValue( int nth );

    // get error string from row
    // NULL if no error; Must be freeed after use
    char *error( ); 
    
    // row hasError?
    // 1: yes  0: no
    int hasError( );
    
    // free memory of row fields
    int freeRow( );
	
    // free memory of row fields alias of freeRow
    int freeResult( );
    
    // returns a pointer to char string as value for name
    // The buffer needs to be freed after use
    char *getValue( const char *name );
    
    // returns a integer
    // 1: if name exists in row; 0: if name does not exists in row
    int getInt(  const char *name, int *value );
    
    // returns a long
    // 1: if name exists in row; 0: if name does not exists in row
    int getLong(  const char *name, long *value );
    
    // returns a float value
    // 1: if name exists in row; 0: if name does not exists in row
    int getFloat(  const char *name, float *value );
    
    // returns a float value
    // 1: if name exists in row; 0: if name does not exists in row
    int getDouble(  const char *name, double *value );
    
    // return data buffer in row  and key/value length
    // char *getData( int *keyLength, int *valueLength );
    
    // return data buffer in row  and key/value length
    char *getMessage( ); 
    
    // close and free up memory
    void close( bool quit=true );

	// client initializes the row
	int initRow();

	// get socket
	int getSocket() const;

    // count number of occurences of character ch in a string
    static int _strchrnum( const char *str, char ch );
#ifdef _WINDOWS64_
    static int _rayrecv( SOCKET sock, char *hdr, int N );
    static int _raysend( SOCKET sock, const char *hdr, int N );
#else
    static int _rayrecv( int sock, char *hdr, int N );
    static int _raysend( int sock, const char *hdr, int N );
#endif

	int getColumnCount();
	char *getCatalogName( int col );
	char *getColumnClassName( int col );
	int getColumnDisplaySize( int col );
	char *getColumnLabel( int col );
	char *getColumnName( int col );
	int getColumnType( int col );
	char *getColumnTypeName( int col );
	int getScale( int col );
	char *getSchemaName( int col );
	char *getTableName( int col );
	bool isAutoIncrement( int col );
	bool isCaseSensitive( int col );
	bool isCurrency( int col );
	bool isDefinitelyWritable( int col );
	int  isNullable( int col );
	bool isReadOnly( int col );
	bool isSearchable( int col );
	bool isSigned( int col );

  protected:
  	ADB  	*_adb;
	ADBROW  *_row;

	// malloc ADB object, and return pointer to onject
	// return malloc( sizeof( ADB ) );
	// NULL for error
  	ADB     *_init();
	RayReadWriteLock   *_lock;
	bool    _destroyed;

    // Parse error msg from _END_[T=ddd|E=Error 1002 Syntax error in ...|X=...]
    // NULL: if no error
    // malloced string containing error message, must tbe freeed.
    char *_getField( const char * rowstr, char fieldToken );
    
    // client receives a row with all columns
    int _printRow( FILE *outf, char **retstr, int nth );
    
    // client receives a row with selected columns
    // int _printSelCol( FILE *outf, char **retstr, int nth );
    
    // clean up memory in the row
    int _cleanupRow( bool endQuery=true );
    
    // free up data part only
    int _freeRowData( );
    
    
    // int _parseCol( );
    
    // parse tokens from command
    // int _parseTokens(const char *str,  const char *start, const char * end, char sep, char *result[], int *len );
    
    int _strInStr( const char *str, int len, const char *str2 );
    
	// char *_getValueFromRec(  const char *longName, const char *pval );

    
    
    ////////// clock ///////////
    typedef struct _RAYCLOCK  RayClock;
    void rayClockStart( RayClock* clock );
    void rayClockStop( RayClock* clock );
    int  rayClockElapsed( RayClock* clock );
    
    //////////////// ray schema part ////////////////////////////
    // int findKeyOffsetLength( const char *schemarec, const char *keyname, RaySchemaProp *prop );
    // int findAllKeyProperty( const char *schemarec, char *keyname[], RaySchemaProp prop[], int *len );
    // int findAllKeyProperty( const char *schemarec, RaySchemaProp prop[], int *len );
    // int findKeyLength( const char *schemarec ); 
    // int findValueLength( const char *schemarec ); 
    // int findAllKeyValueProperty( );

    int findAllMetaKeyValueProperty( RayRecord &rrec );
	// int findSelColNth( int col );
	// int buildSelColNth();

	void _printSelectedCols();
	// void _buildColHash( const char *hdrbuf );

	int _parseSchema( const char *schema );
	// bool  getNthRayRecord( int n, RayRecord& rayrec );
	bool  _getKeyOrValue( const char *key, AbaxDataString & strValue, char &type );
	// int 	numRayRecords();
	// bool  getValueFromRayRecord( const char * key, AbaxDataString &strValue );
	// bool getColProp( const char *key, AbaxDataString &col, char &coltype, char &ktype, int &offset, int &len, int &sig );

	int  setOneCmdProp( int pos );
	// int  setDbtablist( int pos );

	int  _tdiff;

	bool _end;
	bool _hasReply;

	AbaxDataString  _host;
	short		    _port;
	AbaxDataString  _username;
	AbaxDataString  _password;
	AbaxDataString  _dbname;
	AbaxDataString  _unixSocket;
	unsigned long   _clientFlag ;

};


#endif

