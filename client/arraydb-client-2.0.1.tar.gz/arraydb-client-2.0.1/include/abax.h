///////////////////////////////////////////////////////////////////////////////////////
//
//  Exeray Inc, All Rights Reserved   www.exeray.com
//
//  THIS SOFTWARE IS PROVIDED BY EXERAY INC "AS IS" AND ANY EXPRESS OR IMPLIED 
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
//  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
//  EVENT SHALL EXERAY INC BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
//  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
//  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
//  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
//  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////////////////

#ifndef _abax_header_h_
#define _abax_header_h_

#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <limits.h>
#include <stdint.h>
#include <string>
#include <AbaxFormat.h>


#define ABAX_HASHARRNULL LONG_MIN
typedef long abaxint;

/////////////// Enum Types //////////////////
enum AbaxType { ABAX_STATIC = 10, ABAX_DYNAMIC = 20 };
enum AbaxDestroyAction { ABAX_NOOP=0, ABAX_FREE = 10 };
enum { ABAXITERALL=0, ABAXITERSTART=10, ABAXITERCOUNT=20, ABAXITERSTARTCOUNT=30, ABAXITERSTARTEND=40 };
enum AbaxBegin { ABAXNO=0, ABAXYES=1 };
enum AbaxStepAction { ABAX_NOMOVE=0, ABAX_NEXT=1 };
enum AbaxGraphType { ABAX_UNDIRECTED=0, ABAX_DIRECTED=1 };
enum AbaxLinkType { ABAX_DOUBLELINK=0, ABAX_INLINK=1, ABAX_OUTLINK=2 };
enum AbaxQueueType { ABAX_MINQUEUE=1, ABAX_MAXQUEUE=2 };

typedef std::string AbaxDataString;

class abaxstream
{
	public:

	abaxstream & operator<< ( const char *str );
	abaxstream & operator<< ( int n );
	abaxstream & operator<< ( unsigned int n );
	abaxstream & operator<< ( unsigned char n );
	abaxstream & operator<< ( unsigned short n );
	abaxstream & operator<< ( float f);
	abaxstream & operator<< ( double d);
	abaxstream & operator<< ( long l );
	abaxstream & operator<< ( unsigned long l );
	abaxstream & operator<< ( const AbaxDataString &str );

};
extern abaxstream abaxcout;
extern const char* abaxendl; 

// Basic numerical types
template <class DataType>
class AbaxNumeric 
{
    template <class DataType2 > friend abaxstream& operator<< ( abaxstream &os, const AbaxNumeric<DataType2> & d );

    public:
        static DataType randomValue( int size ) { return rand(); }  // todo

        static bool isString( ) { return false; }
		static AbaxNumeric NULLVALUE; 
        inline AbaxNumeric( ) { _data = 0; };
        inline AbaxNumeric( DataType d ) { _data = d ; }

        inline DataType value() const { return _data; }
        inline const char *addr() const { return (const char*)&_data; }
        inline const int addrlen() const { return 0; }
        inline long hashCode() const { 
			DataType positive = _data; if ( _data < 0 ) positive = 0 - _data;
			return ( (unsigned long)positive + ((unsigned long)positive >>1)  ) % LONG_MAX;
		}
        inline long toLong() const { return (unsigned long)_data; }

        inline void destroy( AbaxDestroyAction action ) { };
		inline AbaxDataString toString() const { char buf[16]; sprintf(buf, "%ld", _data ); return buf; }
		inline void valueDestroy( AbaxDestroyAction action ) {}

        inline AbaxNumeric&  operator= ( const AbaxNumeric &s2 ) {
            _data = s2._data;
            return *this;
        }
        inline int operator== ( const AbaxNumeric &s2 ) const {
            return (_data == s2._data );
        }
        inline int operator!= ( const AbaxNumeric &s2 ) const {
            return ( ! ( _data == s2._data ) );
        }

        inline AbaxNumeric& increment(  ) {
            ++ _data; return *this;
        }
        inline AbaxNumeric& decrement(  ) {
            -- _data; return *this;
        }

        inline int operator< ( const AbaxNumeric &s2 ) const {
            return (_data < s2._data );
        }
        inline int operator<= ( const AbaxNumeric &s2 ) const {
            return (_data <= s2._data );
        }
        inline int operator> ( const AbaxNumeric &s2 ) const {
            return (_data > s2._data );
        }
        inline int operator>= ( const AbaxNumeric &s2 ) const {
            return (_data >= s2._data );
        }

        inline AbaxNumeric& operator+= ( const AbaxNumeric &s2 ) {
            _data +=  s2._data;
			return *this;
        }

    private:
        DataType _data;
};

void MurmurHash3_x64_128 ( const void * key, const int len, const unsigned int seed, void * out );

class AbaxString 
{
    friend abaxstream & operator<< ( abaxstream &os, const AbaxString& );

    public:
        static AbaxDataString randomValue( int size=4)
		{
            int i, j;
            static char cset[] = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; // 62 total
            char *mem = new char[size+1];
            for ( i = 0; i< size; i++) {
                j = rand() % 62;
                mem[i] = cset[j];
            }
            mem[i] = '\0';
            AbaxDataString str = mem;
            delete [] mem;
            mem = 0;
            return str;
		}

        static bool isString( ) { return true; }
		static AbaxString NULLVALUE; 

        AbaxString( ) { };
        AbaxString( const AbaxDataString &str ) { _str = str; }
        AbaxString( const char *str ) { _str = str; }
        AbaxString( const char *str, int len ) { _str = AbaxDataString(str, len); }

        inline const AbaxDataString &value() const { return _str; }
		inline const AbaxDataString &toString()  const { return _str; }

		inline const char *addr() const { return _str.c_str(); }
		inline const abaxint addrlen() const { return _str.size(); }
		inline const char *c_str() const { return _str.c_str(); }
		inline const abaxint size() const { return _str.size(); }
        ~AbaxString( ) { };

        inline long hashCode() const 
		{
                unsigned int hash[4];                
                unsigned int seed = 42;             
                register void *str = (void *)this->_str.c_str();
                int len = _str.size();
                MurmurHash3_x64_128( str, len, seed, hash);
                uint64_t res2 = ((uint64_t*)hash)[0]; 
                long res = res2 % LONG_MAX;
            	return res;
		}

        inline void destroy( AbaxDestroyAction action ) { };
		inline void valueDestroy( AbaxDestroyAction action ) {}

        inline  AbaxString&  operator= ( const AbaxString &s2 ) {
            _str = AbaxDataString( s2._str ); 
			return *this;
        }
        inline  int operator== ( const AbaxString &s2 )  const {
            return (_str == s2._str );
        }
        inline  int operator!= ( const AbaxString &s2 )  const {
            return ( ! (_str == s2._str ) );
        }
        inline  int operator< ( const AbaxString &s2 ) const {
            return (_str < s2._str );
        }
        inline  int operator<= ( const AbaxString &s2 ) const {
            return (_str <= s2._str );
        }
        inline  int operator> ( const AbaxString &s2 ) const {
            return (_str > s2._str );
        }
        inline  int operator>= ( const AbaxString &s2 ) const {
            return (_str >= s2._str );
        }

		inline AbaxString& operator+= (const AbaxString &s ) {
			_str += s._str;
			return *this;
		}

		inline AbaxString operator+ (const AbaxString &s ) const {
			AbaxString res = *this;
			res += s;
			return res;
		}

        inline long toLong() const { return atol(_str.c_str()); }


    private:
        AbaxDataString _str;

};


// typedef AbaxString AbaxFixString;
class AbaxFixString 
{
    public:

		static AbaxFixString NULLVALUE; 
        AbaxFixString() 
		{
			_buf = NULL;
			_length = 0;
		}

        AbaxFixString( const char *str, unsigned int len ) 
		{ 
			_buf = (char*)malloc(len+1);
			// memset( _buf, 0, len+1);
			memcpy( _buf, str, len );
			_buf[len] = '\0';
			_length = len;
		}

        AbaxFixString( const AbaxFixString &str ) 
		{ 
			int len = str._length;

			_buf = (char*)malloc(len+1);
			// memset( _buf, 0, len+1);
			memcpy( _buf, str._buf, len );
			_buf[len] = '\0';
			_length = len;
		}
		
		AbaxFixString( const AbaxDataString &str ) 
		{ 
			int len = str.size();

			_buf = (char*)malloc(len+1);
			// memset( _buf, 0, len+1);
			memcpy( _buf, str.c_str(), len );
			_buf[len] = '\0';
			_length = len;
		}

        AbaxFixString& operator=( const AbaxFixString &str ) 
		{ 
			if ( _buf == str._buf ) {
				return *this;
			}

			if ( _buf ) {
				free ( _buf );
			}

			int len = str._length;

			_buf = (char*)malloc(len+1);
			memset( _buf, 0, len+1);
			memcpy( _buf, str._buf, len );
			_length = len;
			return *this;
		}
 		
		AbaxFixString& operator=( const AbaxDataString &str ) 
		{ 
			if ( _buf ) {
				free ( _buf );
			}

			int len = str.size();
			_buf = (char*)malloc(len+1);
			// memset( _buf, 0, len+1);
			memcpy( _buf, str.c_str(), len );
			_buf[len] = '\0';
			_length = len;
			return *this;
		}
        inline  int operator== ( const AbaxFixString &s2 )  const {
            return (memcmp(_buf, s2._buf, _length ) == 0);
        }
		/*
        inline  int operator!= ( const AbaxFixString &s2 )  const {
            return (memcmp(_buf, s2._buf, _length ) != 0);
        }
        inline  int operator< ( const AbaxFixString &s2 ) const {
            return (memcmp(_buf, s2._buf, _length ) < 0);
        }
        inline  int operator<= ( const AbaxFixString &s2 ) const {
            return (memcmp(_buf, s2._buf, _length ) <= 0);
        }
        inline  int operator> ( const AbaxFixString &s2 ) const {
            return (memcmp(_buf, s2._buf, _length ) > 0);
        }
        inline  int operator>= ( const AbaxFixString &s2 ) const {
            return (memcmp(_buf, s2._buf, _length ) >= 0);
        }
		*/

		~AbaxFixString()
		{
			if ( _buf )
			{
				free ( _buf );
				_buf = NULL;
			}
		}
		
		inline const char *addr() const { return _buf; }
		inline const char *c_str() const { return _buf; }
		inline const int addrlen() const { return _length; }
		inline const int size() const { return _length; }
        inline void destroy( AbaxDestroyAction action ) { };

        // inline long hashCode64() const 
        inline long hashCode() const 
		{
                unsigned int hash[4];                
                unsigned int seed = 42;             
                register void *str = (void *)_buf;
                int len = _length;
                MurmurHash3_x64_128( str, len, seed, hash);
                uint64_t res2 = ((uint64_t*)hash)[0]; 
                long res = res2 % LONG_MAX;
            	return res;
		}

	private:
		char           *_buf;
		unsigned int   _length;

};


// A memory buffer type
class AbaxBuffer 
{
    friend abaxstream & operator<< ( abaxstream &os, const AbaxBuffer& );

    public:
        AbaxBuffer( ) {  _ptr = NULL; };
        static bool isString( ) { return false; }
		static AbaxBuffer NULLVALUE; 

         ~AbaxBuffer( ) {  };
        AbaxBuffer( void *ptr ) { _ptr = ptr; }
        inline void *value() const { return _ptr; }
        inline const char *addr() const { return (const char *)_ptr; }
        inline const int addrlen() const { return 0; }
		inline const AbaxDataString toString()  const { return ""; }

        long hashCode() const { return 1; } 
        void destroy( AbaxDestroyAction action ) { 
            if ( _ptr ) {
                if ( action == ABAX_FREE ) { free( _ptr ); } 
                _ptr = NULL; 
            }
        }
		inline void valueDestroy( AbaxDestroyAction action ) { destroy(action); }
        static void * randomValue( int s ) {
            return (void*)0x83393;
        }

        inline AbaxBuffer&  operator= ( const AbaxBuffer &p2 ) {
            _ptr = p2._ptr; return *this;
        }
        inline AbaxBuffer&  operator= ( void *ptr ) {
            _ptr = ptr; return *this;
        }

        inline int operator== ( const AbaxBuffer &p2 )  const {
            return (_ptr == p2._ptr );
        }
        inline int operator!= ( const AbaxBuffer &p2 )  const {
            return ( ! (_ptr == p2._ptr ) );
        }
        inline int operator< ( const AbaxBuffer &p2 ) const {
            return (_ptr < p2._ptr );
        }
        inline int operator<= ( const AbaxBuffer &p2 ) const {
            return (_ptr <= p2._ptr );
        }
        inline  int operator> ( const AbaxBuffer &p2 ) const {
            return (_ptr > p2._ptr );
        }
        inline  int operator>= ( const AbaxBuffer &p2 ) const {
            return (_ptr >= p2._ptr );
        }

		inline AbaxBuffer& operator += ( const AbaxBuffer &p2 ) {
			return *this;
		}

        inline int toInt() const { return 0; }

    private:
        void *_ptr;

};


// typedef of data types
typedef AbaxNumeric<long> AbaxLong;
typedef AbaxNumeric<int> AbaxInt;
typedef AbaxNumeric<short> AbaxShort;
typedef AbaxNumeric<float> AbaxFloat;
typedef AbaxNumeric<double> AbaxDouble;
typedef AbaxNumeric<char> AbaxChar;


// Key-Value pair type
#pragma pack(4)
template <class KType,class VType>
class AbaxPair
{
    template <class K2,class V2> friend abaxstream& operator<< ( abaxstream &os, const AbaxPair<K2, V2> & pair );

    public:

        KType key;
        VType value;

		static  AbaxPair  NULLVALUE;

        inline AbaxPair() {}
        inline ~AbaxPair() {}

        inline AbaxPair( const KType &k) : key(k) {}
        inline AbaxPair( const KType &k, const VType &v) : key(k), value(v) {}
        inline int lt (const AbaxPair &d2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 && KType::isString() ) {
				return ( compareString<KType>(key, d2.key, fmt) < 0 ?1:0 );
			} else {
            	return ( key < d2.key );
			}
        }

		inline AbaxPair( const AbaxPair& other ) 
		{
			key = other.key;
			value = other.value;
		}
		inline AbaxPair& operator= ( const AbaxPair& other )
		{
			key = other.key;
			value = other.value;
			return *this;
		}


        inline int operator< ( const AbaxPair &d2 ) const {
           	return ( key < d2.key );
		}
        inline int operator<= ( const AbaxPair &d2 ) const {
           	return ( key <= d2.key );
		}
		
        inline int le (const AbaxPair &d2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 && KType::isString() ) {
				return ( compareString<KType>(key, d2.key, fmt) <= 0 ?1:0 );
			} else {
            	return ( key <= d2.key );
			}
        }
        inline int operator> ( const AbaxPair &d2 ) const {
           	return ( key > d2.key );
		}
        inline int operator>= ( const AbaxPair &d2 ) const {
           	return ( key >= d2.key );
		}

        inline int gt ( const AbaxPair &d2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 && KType::isString() ) {
				return ( compareString<KType>(key, d2.key, fmt) > 0 ?1:0 );
			} else {
            	return ( key > d2.key );
			}
        }
        inline int ge ( const AbaxPair &d2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 && KType::isString() ) {
				return ( compareString<KType>(key, d2.key, fmt) >= 0 ?1:0 );
			} else {
            	return ( key >= d2.key );
			}
        }
        inline int operator== ( const AbaxPair &d2 ) const
        {
           	return ( key == d2.key );
        }
        inline int operator!= ( const AbaxPair &d2 ) const
        {
            return ( ! ( key == d2.key ) );
        }

        inline int compare( const AbaxPair &d2, const AbaxFormat &fmt ) const
        {
			if ( fmt.len>0 && KType::isString() ) {
				return ( compareString<KType>(key, d2.key, fmt) );
			} 

            if ( key < d2.key ) {
                return -1;
            } else if ( key > d2.key ) {
                return 1;
            } else {
                return 0;
            }
        }

        inline void setValue( const VType &newvalue ) {
            value = newvalue;
        }

		inline void valueDestroy( AbaxDestroyAction action ) {
			value.destroy( action );
		}

        inline long hashCode() const { return key.hashCode(); }

};
#pragma pack()


template <class K> class AbaxKeyPair;

// Light-weight object with a reference to key only
template <class K >
class AbaxKey
{ 
    public: 

    AbaxKey(const K &k ): key(k) {};
    AbaxKey(const AbaxKey<K> &ref) : key(ref.key) {};
    AbaxKey(AbaxKeyPair<K> &pair); 

    const K &key; 
};

// Light-weight class containing only references to key-vaue
template <class K, class V>
class AbaxKeyValue
{ 
    public: 

    AbaxKeyValue(const K &k, V &v): key(k), value(v) {};
    AbaxKeyValue(const K &k ): key(k) {};
    AbaxKeyValue(const AbaxKeyValue<K,V> &ref) : key(ref.key), value(ref.value) {};

    const K &key; 
    V &value; 
};

// Light-weight class with pointers pointing to key-value
template <class K, class V>
class AbaxPtrKeyValue
{ 
    public: 

    AbaxPtrKeyValue(K *k, V *v): key(k), value(v) {};
    AbaxPtrKeyValue(K *k ): key(k) {};
    AbaxPtrKeyValue(const AbaxPtrKeyValue<K,V> &p2) : key(p2.key), value(p2.value) {};

    K *key; 
    V *value; 
};

// Clock Class
class AbaxClock
{

    public:
    AbaxClock()
    {
		start();
    }

    void start()
    {
        struct timeval now;
        gettimeofday( &now, NULL ); 
        endsec = beginsec = now.tv_sec;
        endmsec = beginmsec = now.tv_usec/1000;
        endusec = beginusec = now.tv_usec;
    }

    void stop()
    {
        struct timeval now;
        gettimeofday( &now, NULL ); 
        endsec = now.tv_sec;
        endmsec = now.tv_usec/1000;
        endusec = now.tv_usec;
    }

    // return elapsed time in milliseconds
    int elapsed()
    {
        return ( 1000*(endsec - beginsec) + ( endmsec - beginmsec ) );
    }
    int elapsedusec()
    {
        return ( 1000000*(endsec-beginsec) + ( endusec - beginusec ) );
    }
	void print( const char *hdr ) {
		printf("%s elapsed %d usecs\n", hdr, elapsedusec() );
		fflush( stdout );
	}
	void flash( const char *hdr ) {
		stop();
		printf("%s elapsed %d usecs\n", hdr, elapsedusec() );
		fflush( stdout );
		start();
	}

    private:
        int  beginsec, beginmsec, beginusec;
        int  endsec, endmsec, endusec;

};


// Memory Class
class AbaxMemory
{
    public:
    AbaxMemory()
    {
        endkb = beginkb = 0; 
    }

    void start()
    {
		beginkb = snapShot();
    }

    void stop()
    {
		endkb = snapShot();
    }

    // return incremented memory usage in MB
    int used()
    {
        return ( endkb - beginkb )/1024;
    }

    private:
        int  beginkb, endkb; 

		int snapShot()
        {
            char *ptr;
            int sz;
            char fn[256];
            static char line[256];
            pid_t pid = getpid();
            sprintf(fn, "/proc/%d/status", pid );
        
            FILE *fp = fopen(fn, "r");
            if ( ! fp ) return 0;
        
            while ( NULL != fgets( line, 256, fp) ) {
                sz = strlen(line);
                if ( strstr( line, "VmRSS:") ) {
                    fclose( fp );
                    line[sz-1]='\0';
                    ptr = &line[7];
                    while ( ! isdigit(*ptr) ) ptr++;
                    return atoi(ptr);
                }
            }
            fclose( fp );
            return 0;
        }

};



// Key-Value pair type
template <class KType,class VType>
class AbaxKeyKeyPair
{
    template <class K2,class V2> friend abaxstream& operator<< (abaxstream &os, const AbaxKeyKeyPair<K2, V2> & pair );

    public:

        KType key1;
        KType key2;
        VType value;

		static  AbaxKeyKeyPair  NULLVALUE; 
		static const long   HALFMAX = LONG_MAX >> 1;

        inline AbaxKeyKeyPair() {}
        inline AbaxKeyKeyPair( const KType &k1 ) : key1(k1), key2(k1) {}
        inline AbaxKeyKeyPair( const KType &k1, const KType &k2) : key1(k1), key2(k2) {}
        inline AbaxKeyKeyPair( const KType &k1, const KType &k2, const VType &v) : key1(k1), key2(k2), value(v) {}
        inline int lt (const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<d2.key2 ) );
        }
        inline int operator< (const AbaxKeyKeyPair &d2 ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<d2.key2 ) );
        }

        inline int le (const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<=d2.key2 ) );
        }
        inline int operator<= (const AbaxKeyKeyPair &d2 ) const
        {
           	return ( key1 < d2.key1 || ( key1==d2.key1 && key2<=d2.key2 ) );
        }

        inline int gt ( const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>d2.key2 ) );
        }
        inline int operator> ( const AbaxKeyKeyPair &d2 ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>d2.key2 ) );
        }

        inline int ge ( const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>=d2.key2 ) );
        }
        inline int operator>= ( const AbaxKeyKeyPair &d2 ) const
        {
           	return ( key1 > d2.key1 || ( key1==d2.key1 && key2>=d2.key2 ) );
        }

        inline int operator== ( const AbaxKeyKeyPair &d2 ) const
        {
           	return ( key1 == d2.key1 && key2==d2.key2 );
        }
        inline int operator!= ( const AbaxKeyKeyPair &d2 ) const
        {
           	return ( ! ( key1 == d2.key1 && key2==d2.key2 ) );
        }
        inline int isKey1Null() const
        {
           	return ( key1 == KType::NULLVALUE );
        }
        inline int isKey2Null() const
        {
           	return ( key2 == KType::NULLVALUE );
        }

        inline int compare( const AbaxKeyKeyPair &d2, const AbaxFormat &fmt ) const
        {
            if ( lt(d2, fmt) ) {
                return -1;
            } else if ( gt( d2, fmt) ) {
                return 1;
            } else {
                return 0;
            }
        }

        inline AbaxKeyKeyPair&  operator= ( const AbaxKeyKeyPair &d2 )
        {
            key1 = d2.key1;
            key2 = d2.key2;
            value = d2.value;
            return *this;
        }

        inline void setValue( const VType &newvalue ) {
            value = newvalue;
        }

		inline void valueDestroy( AbaxDestroyAction action ) {
			value.destroy( action );
		}

        inline long hashCode() const { 
			long h1 = key1.hashCode(); 
			if ( isKey2Null() ) return h1;

			long h2 = key2.hashCode(); 
			if ( isKey1Null() ) return  h2;

			if ( h1 < HALFMAX ) {
				return h1+ (h2>>1);
			} else {
				return (h1 >> 1) + (h2 >> 2);
			}

		}
};


#ifdef _WINDOWS64_
#define RAY_NOATIME 0
#else
#ifdef _CYGWIN_
#define RAY_NOATIME 0
#else
#define RAY_NOATIME O_NOATIME
#endif
#endif

#define RAY_BLOCK_SIZE 32
//#define RAY_BLOCK_SIZE 4

#endif
