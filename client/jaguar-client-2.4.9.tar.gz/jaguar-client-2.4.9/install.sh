#!/bin/bash

##########################################################################################
##  DataJaguar Inc.
##
##  Install script for Jaguar client 
##
##  ./install.sh     (You should execute this script on each host in your cluster)
##
##########################################################################################

### users can change this to a different directory
export  JAGUAR_HOME=$HOME

/bin/mkdir -p $JAGUAR_HOME/jaguar/bin
/bin/mkdir -p $JAGUAR_HOME/jaguar/conf
/bin/mkdir -p $JAGUAR_HOME/jaguar/data
/bin/mkdir -p $JAGUAR_HOME/jaguar/index
/bin/mkdir -p $JAGUAR_HOME/jaguar/log
/bin/mkdir -p $JAGUAR_HOME/jaguar/doc
/bin/mkdir -p $JAGUAR_HOME/jaguar/include
/bin/mkdir -p $JAGUAR_HOME/jaguar/lib
/bin/mkdir -p $JAGUAR_HOME/jaguar/tmp
/bin/mkdir -p $JAGUAR_HOME/jaguar/backup

/bin/cp -f  jql jag jbench genrand rlwrap $JAGUAR_HOME/jaguar/bin
/bin/cp -f include/*.h $JAGUAR_HOME/jaguar/include
/bin/cp -f lib/*.a lib/*.so lib/*.jar lib/*.dll lib/jaguarnode.node $JAGUAR_HOME/jaguar/lib
/bin/cp -f *.ini *.conf $JAGUAR_HOME/jaguar/conf

/bin/cp -f  example.* README.* comp*.sh *.sql jcallinfo goexample.* $JAGUAR_HOME/jaguar/doc

echo "Successfully installed Jaguar client in $JAGUAR_HOME/jaguar"

