#ifndef _jaguar_reader_
#define _jaguar_reader_

#include <abax.h>

class ArrayDB;
class ExpressionElementNode;
class BinaryExpressionBuilder;
class RayRecord;
class RaySchemaAttribute;
class AbaxBuffReader;
template <class K, class V> class AbaxHashMap;

#define TYPE_BOOLEAN 1
#define TYPE_TINYINT 10
#define TYPE_SMALLINT 12
#define TYPE_MEDIUMINT 14
#define TYPE_INT 16
#define TYPE_BIGINT 18
#define TYPE_FLOAT 30
#define TYPE_DOUBLE 40
#define TYPE_TIME 50
#define TYPE_DATE 55
#define TYPE_STRING 60

class JaguarReader
{

  public:
		JaguarReader( const char *dbName, const char *tableName, const char *where=NULL );
		~JaguarReader(); 
		bool    begin();
		bool    next();

		// per row values
		AbaxDataString getString( const char *name );  // name can be a key field or value field
		int    getInt( const char *name );  // name can be a key field or value field
		long    getLong( const char *name );  // name can be a key field or value field
		float    getFloat( const char *name );  // name can be a key field or value field
		double    getDouble( const char *name );  // name can be a key field or value field
		AbaxDataString    getTimeString( const char *name );  // name can be a key field or value field
		AbaxDataString    getDateString( const char *name );  // name can be a key field or value field

		// per table values
		int	    getType( const char *name );  // type of a column
		long    size() const;    // how many non-empty elements
		long    capacity() const;   // how many cells in the array
		int	    getFD();
		int     keyLength();
		int     valueLength();
		void	setConcurrent();

  protected:
 	int 								_KEYLEN;
	int 								_VALLEN;
	int 								_KEYVALLEN;
    int 								_numCols;
    int 								_numKeys;
	char 								*_buffer;	
	const char 							*_dbName;
	const char 							*_tableName;
  	ArrayDB 							*_arraydb;
	AbaxBuffReader 						*_buffRead;
	AbaxHashMap<AbaxString, abaxint> 	*_tablemap;
	BinaryExpressionBuilder 			*_whereTree;
	ExpressionElementNode 				*_root;
	RayRecord 							*_record;	
	RaySchemaAttribute 					*_schAttr;
	
	AbaxDataString getOneField( const char *name );  // getOneField

};


#endif

