#!/bin/bash

##########################################################################################
##
##  Install script for $brand client 
##
##  ./install             (install on single host system)
##  ./install cluster     (install on cluster system)
##
##########################################################################################

brand=`cat brand.txt`
HOMEDIR=$HOME

cluster=$1
if [[ "x$cluster" = "xcluster" ]]; then
    userid=`id -u`
    if ((userid != 0 )); then
        echo "Please run this script as root or sudo"
        exit 1
    fi
	HOMEDIR=/home/jaguar
fi

/bin/mkdir -p $HOMEDIR/$brand/bin
/bin/mkdir -p $HOMEDIR/$brand/conf
/bin/mkdir -p $HOMEDIR/$brand/data
/bin/mkdir -p $HOMEDIR/$brand/index
/bin/mkdir -p $HOMEDIR/$brand/log
/bin/mkdir -p $HOMEDIR/$brand/doc
/bin/mkdir -p $HOMEDIR/$brand/include
/bin/mkdir -p $HOMEDIR/$brand/lib
/bin/mkdir -p $HOMEDIR/$brand/tmp

/bin/cp -f  jcli jag jbench genrand rlwrap $HOMEDIR/$brand/bin
#/bin/cp -f  *.conf $HOMEDIR/$brand/conf
/bin/cp -f include/*.h $HOMEDIR/$brand/include
/bin/cp -f lib/lib*.a lib/lib*.so lib/*.jar lib/*.dll $HOMEDIR/$brand/lib

/bin/cp -f *.cc *.java README.* comp*.sh *.sql jcallinfo $HOMEDIR/$brand/doc

echo "Successfully installed $brand client in $HOMEDIR/$brand"

