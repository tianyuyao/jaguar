#!/bin/bash

##########################################################################################
##
##  Install script for rdb client  (Revolutionary Database)
##
##########################################################################################

/bin/mkdir -p $HOME/arraydb/bin
/bin/mkdir -p $HOME/arraydb/conf
/bin/mkdir -p $HOME/arraydb/data
/bin/mkdir -p $HOME/arraydb/log
/bin/mkdir -p $HOME/arraydb/doc
/bin/mkdir -p $HOME/arraydb/include
/bin/mkdir -p $HOME/arraydb/lib

/bin/cp -f adbcli abench genrand rlwrap $HOME/arraydb/bin
/bin/cp -f include/*.h $HOME/arraydb/include
/bin/cp -f lib/lib*.a lib/lib*.so $HOME/arraydb/lib


echo "Successfully installed ArrayDB client in $HOME/arraydb"



