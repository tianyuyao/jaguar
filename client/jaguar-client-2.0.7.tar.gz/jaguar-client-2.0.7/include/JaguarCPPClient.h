#ifndef _jaguar_cpp_client_h_
#define _jaguar_cpp_client_h_

#define RAY_SOCK_MSG_HDR_LEN  10
#define RAY_ERR_MSG_LEN  256
#define RAY_MAX_NUM_KEYS  256
#define RAY_COL_MAX 512
#define RAY_NAME_MAX 64 
#define RAY_SESSIONID_MAX 32


#ifdef _WINDOWS64_
#include<winsock2.h> 
#include <stdio.h>

#ifdef EXPORT_DLL
#define LIB_API __declspec(dllexport)
#else
#define LIB_API
#endif

#else
#define LIB_API
#endif

//#include <string>
#include <abax.h>
#include <rayhashtable.h>


class RayReadWriteLock;
class RayRecord;


typedef struct _RaySchemaProp {
	char    keyname[RAY_NAME_MAX];
	int 	offset;
	int 	length;
	char 	type;
	int  	sig;
} RaySchemaProp ;


typedef struct _RayKeyValProp {
	char  dbname[RAY_NAME_MAX];
	char  tabname[RAY_NAME_MAX];
	char  colname[RAY_NAME_MAX];
	int 	length;
	char 	type;
	int  	sig;
} RayKeyValProp ;


struct  _RAYCLOCK
{
 	int  beginsec, beginmsec, beginusec;
   	int  endsec, endmsec, endusec;
};

struct  _ADB
{
#ifdef _WINDOWS64_
	SOCKET socket;
#else
	int 	socket;
#endif
    
	char  	errmsg[RAY_ERR_MSG_LEN];
	char  	dbname[RAY_NAME_MAX];
	char    *dbtablist;
	char    *query;
	char  	session[RAY_SESSIONID_MAX];
};
typedef struct _ADB  ADB;

struct _ADBROW
{
	int    retCode;
	char   *hdr;
	char   *data;
	char   *valinfo;
	char   type;
	char   op;
	int    samedb;   // selected tables all from one DB? if yes 1.
	
	//char   *keyname[RAY_MAX_NUM_KEYS];
	RaySchemaProp prop[RAY_MAX_NUM_KEYS];
	int    numKeys;
	int    keyLength;
	int    valueLength;

	int    selectFieldFlag;
	char   selcols[RAY_COL_MAX][RAY_NAME_MAX];
	// int    selcolslength;
	char 	*g_names[1024];
	char 	*g_values[1024];
	// ray_hash_t  colNumMap;
	ray_hash_t  colHash;

	int		isMeta;
	int		colCount;

	ADB    *adb;
	void   *etc;

	RayKeyValProp keyvalprop[RAY_COL_MAX];
	int    numKeyVals;
};
typedef struct _ADBROW  ADBROW;


class LIB_API JaguarCPPClient 
{
  public:
  	JaguarCPPClient();
	~JaguarCPPClient();
	void destroy();

	// 0: error  1: OK   adb->sock = socket() ....
	// send username and password to socket. Server verifies and sends authentication
	// info back from server. OK: 1  error: 0
	int connect( const char *ipaddress, unsigned int port, 
				const char *username, const char *passwd,
				const char *dbname, const char *unixSocket,
				unsigned long clientFlag );

    // send command to socket to server
    // 1: OK   0: error
    int query( const char *query );   // send query command over sock to server in adb object

    // server sends number of columns in the result over socket
    // client receives a row
    // 0: error or reaching the last record
    // 1: successful and having more records
    int reply( bool headerOnly = false );

	// get session string
	const char *getSession();

	// set Op
	void setOp( char op );

	// get session string
	const char *getDatabase();

    // client receives a row
    int printRow( FILE *outf );

    // get n-th column in the row
    // NULL if not found; malloced char* if found, must be freed later
    char *getNthValue( int nth );

    // get error string from row
    // NULL if no error; Must be freeed after use
    char *error( ); 
    
    // row hasError?
    // 1: yes  0: no
    int hasError( );
    
    // free memory of row fields
    int freeRow( );
	
    // free memory of row fields alias of freeRow
    int freeResult( );
    
    // returns a pointer to char string as value for name
    // The buffer needs to be freed after use
    char *getValue( const char *name );
    
    // returns a integer
    // 1: if name exists in row; 0: if name does not exists in row
    int getInt(  const char *name, int *value );
    
    // returns a long
    // 1: if name exists in row; 0: if name does not exists in row
    int getLong(  const char *name, long *value );
    
    // returns a float value
    // 1: if name exists in row; 0: if name does not exists in row
    int getFloat(  const char *name, float *value );
    
    // returns a float value
    // 1: if name exists in row; 0: if name does not exists in row
    int getDouble(  const char *name, double *value );
    
    // return data buffer in row  and key/value length
    // char *getData( int *keyLength, int *valueLength );
    
    // return data buffer in row  and key/value length
    char *getMessage( ); 
    
    // close and free up memory
    void close( );

	// client initializes the row
	int initRow();

    // count number of occurences of character ch in a string
    static int _strchrnum( const char *str, char ch );
#ifdef _WINDOWS64_
    static int _rayrecv( SOCKET sock, char *hdr, int N );
    static int _raysend( SOCKET sock, const char *hdr, int N );
#else
    static int _rayrecv( int sock, char *hdr, int N );
    static int _raysend( int sock, const char *hdr, int N );
#endif

	int getColumnCount();
	char *getCatalogName( int col );
	char *getColumnClassName( int col );
	int getColumnDisplaySize( int col );
	char *getColumnLabel( int col );
	char *getColumnName( int col );
	int getColumnType( int col );
	char *getColumnTypeName( int col );
	int getScale( int col );
	char *getSchemaName( int col );
	char *getTableName( int col );
	bool isAutoIncrement( int col );
	bool isCaseSensitive( int col );
	bool isCurrency( int col );
	bool isDefinitelyWritable( int col );
	int  isNullable( int col );
	bool isReadOnly( int col );
	bool isSearchable( int col );
	bool isSigned( int col );



  protected:
  	ADB  	*_adb;
	ADBROW  *_row;

	// malloc ADB object, and return pointer to onject
	// return malloc( sizeof( ADB ) );
	// NULL for error
  	ADB     *_init();
	RayReadWriteLock   *_lock;
	bool    _destroyed;



    // Parse error msg from _END_[T=ddd|E=Error 1002 Syntax error in ...|X=...]
    // NULL: if no error
    // malloced string containing error message, must tbe freeed.
    char *_getField( const char * rowstr, char fieldToken );
    
    // client receives a row with all columns
    int _printRowAll( FILE *outf, char **retstr, int nth );
    
    // client receives a row with selected columns
    int _printSelCol( FILE *outf, char **retstr, int nth );
    
    // clean up memory in the row
    int _cleanupRow( );
    
    // free up data part only
    int _freeRowData( );
    
    
    // parse specific columns to the selcols 2D array
    int _parseCol( );
    
    // parse tokens from command
    int _parseTokens(const char *str,  const char *start, const char * end, char sep, char *result[], int *len );
    
    int _strInStr( const char *str, int len, const char *str2 );
    
	char *_getValueFromRec(  const char *longName, const char *pval );

    
    
    ////////// clock ///////////
    typedef struct _RAYCLOCK  RayClock;
    void rayClockStart( RayClock* clock );
    void rayClockStop( RayClock* clock );
    int  rayClockElapsed( RayClock* clock );
    
    //////////////// ray schema part ////////////////////////////
    int findKeyOffsetLength( const char *schemarec, const char *keyname, RaySchemaProp *prop );
    // int findAllKeyProperty( const char *schemarec, char *keyname[], RaySchemaProp prop[], int *len );
    int findAllKeyProperty( const char *schemarec, RaySchemaProp prop[], int *len );
    int findKeyLength( const char *schemarec ); 
    int findValueLength( const char *schemarec ); 
    int findAllKeyValueProperty( );
    int findAllMetaKeyValueProperty( RayRecord &rrec );
	int findSelColNth( int col );
	int buildSelColNth();

	void _printSelectedCols();
	void _buildColHash( RayRecord &rrec );

	void _parseKeySchema( const char *dbtab, const char *schema );
	void _parseValueSchema( const char *dbtab, const char *schema );
	bool  getNthRayRecord( int n, RayRecord& rayrec );
	bool  _getKeyOrValue( const char *key, AbaxDataString & strValue, char &type );
	int 	numRayRecords();
	bool  getValueFromRayRecord( const char * key, AbaxDataString &strValue );
	void  convertTimeToStr( const AbaxDataString& instr, AbaxDataString& outstr );
	bool getColProp( const char *key, AbaxDataString &col, char &coltype, char &ktype, int &offset, int &len, int &sig );



	int  _tdiff;




};


#endif

