/********************************************************************
**  jbench
**
**  Benchmarking program 
**
*********************************************************************/
#include <sys/socket.h>
#include <dirent.h>
#include <netinet/in.h>
#include <stdio.h>
#include <iostream>
#include <unistd.h>
#include <strings.h>
#include <string.h>
#include <pthread.h>
#include <sys/wait.h>

#include <abax.h>
#include <JaguarCPPClient.h>

// Use multi-thread or forking  child processes to connect to server
// #define RBENCH_USETHREAD 1

// Argument passing structure
class TestPass {
    public:
        AbaxDataString  fpath;
        AbaxDataString  username;
        AbaxDataString  passwd;
        AbaxDataString  host;
        AbaxDataString  port;
        AbaxDataString  dbname;
		int				millisec;
		int				isThread;
        AbaxDataString  showflag;
        AbaxDataString  ratiostr;
        int             useRatio;
        AbaxDataString  table;
		int				concurrency;
		int			    keepTable;
};


int  parseArgs( int argc, char *argv[], AbaxDataString &username, AbaxDataString &passwd,
                AbaxDataString &host, AbaxDataString &port, AbaxDataString &dbname,
				AbaxDataString &iter, AbaxDataString &concurrency, AbaxDataString &fpath,
				AbaxDataString &showflag,
				AbaxDataString &ratiostr );
void  usage( const char *prog );
void  *threadTask( void *p );
void  *threadFileTask( TestPass *p );
void  *threadRatioTask( TestPass *p );
void  parseRatio( const char *str, int *insertNum, int *updateNum, int *selectNum );
int   ratioWork( JaguarCPPClient &adb, TestPass *tp, int insertNum, int updateNum, int selectNum, int showflag );
int   initTable(  TestPass *p, const AbaxDataString &table );
int   countFileLines ( const char *fpath );

int main( int argc, char *argv[] )
{
	AbaxDataString username; 
	AbaxDataString passwd;
    AbaxDataString host; 
	AbaxDataString port; 
    AbaxDataString dbname;
    AbaxDataString iter; 
    AbaxDataString concurrency;
    AbaxDataString fpath;
    AbaxDataString showflag;
    AbaxDataString ratiostr;
    AbaxDataString table;
    AbaxDataString keepTable;
	int   		   useRatio = 0;
	int 		   rc;

	// default values
	username = "test";
	passwd = "test";
	host = "127.0.0.1";
	port = "8888";
	dbname = "test";
	iter = "1";
	concurrency = "1";
	showflag = "0";
	keepTable = "1";
	table = "jbench";

	parseArgs( argc, argv, username, passwd, host, port, dbname, iter, concurrency, fpath, showflag, ratiostr );
	if ( fpath.size() < 1 ) {
		if ( ratiostr.size() < 1 ) {
			usage( argv[0] );
			exit( 1 );
		} else {
			useRatio = 1;
		}
	} else {
		if ( ratiostr.size() > 0 ) {
			usage( argv[0] );
			exit( 1 );
		}
		useRatio = 0;
	}


	TestPass pass;
	pass.fpath = fpath;
	pass.host = host;
	pass.port = port;
	pass.username = username;
	pass.passwd = passwd;
	pass.dbname = dbname;
	pass.showflag = showflag;
	pass.ratiostr = ratiostr;
	pass.useRatio = useRatio;
	pass.table = table;
	pass.concurrency = atoi( concurrency.c_str() );
	pass.keepTable = 1;

	rc = initTable( &pass,  table );

	int k = 0;
	int iterLen = atoi ( iter.c_str() );
	int conLen = atoi( concurrency.c_str() );

	int unitQuerys = 1;
	AbaxClock clock;

	if ( useRatio ) {
		int  insertNum = 0;
		int  updateNum = 0;
		int  selectNum = 0;
		parseRatio( ratiostr.c_str(), &insertNum, &updateNum, &selectNum );
		unitQuerys = insertNum + updateNum + selectNum;
	} else {
		unitQuerys = countFileLines ( fpath.c_str() );
	}

	clock.start();
#ifdef RBENCH_USETHREAD
	pthread_t thread[1024];
	pass.isThread = 1;
	for ( int i = 0; i < iterLen; ++i ) {
		for ( int j = 0; j < conLen; ++j ) {
			pthread_create( &thread[j], NULL, threadTask, (void*)&pass );
		}

		for ( int j = 0; j < conLen; ++j ) {
			pthread_join(thread[j], NULL );
		}
	}

#else
	signal(SIGCHLD, SIG_IGN);
	pid_t pid;
	int status;
	pass.isThread = 0;
	for ( int i = 0; i < iterLen; ++i ) {
		for ( int j = 0; j < conLen; ++j ) {
			pid = fork();
			if ( 0 == pid ) {  // child
				threadTask( (void*)&pass );
			} else if ( pid > 0 ) // parent
			{
			} else {
				printf("Error fork new process\n");
				return 1;
			}
		}

		while ((pid = wait( &status )) > 0) { }
	}

#endif

	clock.stop();

	char unit1[64];
	char unit2[64];
	int  millisec = clock.elapsed();
	int  microsec = clock.elapsedusec();
	int timePerIter =  millisec/iterLen/unitQuerys;

	sprintf( unit1, "milli seconds");
	if ( timePerIter < 1 ) {
		timePerIter =  microsec/iterLen/unitQuerys;
		sprintf( unit1, "micro seconds");
	}

	int timePerConcur =  millisec/iterLen/conLen/unitQuerys;
	sprintf( unit2, "milli seconds");
	if ( timePerConcur < 1 ) {
		timePerConcur = microsec/iterLen/conLen/unitQuerys;
		sprintf( unit2, "micro seconds");
	}


    time_t now = time(NULL);
    char   tbuf[64];
    sprintf( tbuf, ctime(&now) );
    tbuf[strlen(tbuf)-1] = '\0';

	printf("\n"); 
	printf("TESTBEGIN\n");
	printf("prog=%s time=%ld date=%s user=%s\n", argv[0], now, tbuf, getenv("USER") );
	printf("\n"); 
	printf("Username:            %s\n", username.c_str() );
	printf("Password:            %s\n", passwd.c_str() );
	printf("Host:                %s\n", host.c_str() );
	printf("Port:                %s\n", port.c_str() );
	printf("Database:            %s\n", dbname.c_str() );
	printf("Table:               jbench\n" );
	printf("SQL File:            %s\n", fpath.c_str() );
	printf("Ratio:               %s\n", ratiostr.c_str() );
	printf("Iterations:          %s\n", iter.c_str() );
	printf("Concurrency:         %s\n", concurrency.c_str() );
	printf("\n"); 
	printf("Total Time:          %d milli seconds\n", clock.elapsed() );
	printf("Time/Iteration:      %d %s\n", timePerIter, unit1 );
	printf("Time/Concurrency:    %d %s\n", timePerConcur, unit2 );
	printf("Requests/Second:     %d\n", unitQuerys*iterLen*conLen*1000/(clock.elapsed()+1) );
	printf("TESTEND\n");
	printf("\n"); 
	fflush( stdout );

	return 0;
}

// parse command line args
int  parseArgs( int argc, char *argv[], AbaxDataString &username, AbaxDataString &passwd,
                AbaxDataString &host, AbaxDataString &port, AbaxDataString &dbname,
				AbaxDataString &iter, AbaxDataString &concurrency, AbaxDataString &fpath,
				AbaxDataString &showflag, AbaxDataString &ratiostr )
{
    int i = 0;
    char *p;

    for ( i = 1; i < argc; ++i )
    {
        if ( 0 == strcmp( argv[i], "-u" ) ) {
            if ( (i+1) <= (argc-1) ) {
                username = argv[i+1];
            }
        } else if ( 0 == strcmp( argv[i], "-p"  )  ) {
            if ( (i+1) <= (argc-1) ) {
                passwd = argv[i+1];
            }
        } else if ( 0 == strcmp( argv[i], "-n"  )  ) {
            if ( (i+1) <= (argc-1) ) {
                iter = argv[i+1];
            }
        } else if ( 0 == strcmp( argv[i], "-c"  )  ) {
            if ( (i+1) <= (argc-1) ) {
                concurrency = argv[i+1];
            }
        } else if ( 0 == strcmp( argv[i], "-s"  )  ) {
            if ( (i+1) <= (argc-1) ) {
                showflag = argv[i+1];
            }
        } else if ( 0 == strcmp( argv[i], "-r"  )  ) {
            if ( (i+1) <= (argc-1) ) {
                ratiostr = argv[i+1];
            }
        } else if ( 0 == strcmp( argv[i], "-f"  )  ) {
            if ( (i+1) <= (argc-1) ) {
                fpath = argv[i+1];
            }
        } else if ( 0 == strcmp( argv[i], "-h"  )  ) {
            if ( (i+1) <= (argc-1) ) {
                if ( NULL != (p=strchr( argv[i+1], ':')) ) {
                    if ( *p == ':' ) {
                        ++p;
                        if ( *p != '\0' ) {
                            port = p;
                        }
                    } else {
                        p = strtok( argv[i+1], ":");
                        host = p;
                        p = strtok( NULL,  ":");
                        if ( p ) {
                            port = p;
                        }
                    }
                } else {
                    host = argv[i+1];
                }
            }


        } else {
			printf("Invalid option %s\n", argv[i] );
			usage( argv[0] );
			exit(1);
		}
		
		++i;
    }
}

// print help
void usage( const char *prog )
{
	printf("\n");
	printf("%s  [-u USERNAME -p PASSWORD -h HOST:PORT -n IERATIONS -c CONCURRENCY -s SHOWFLAG] [-f SQLFILE] [-r I:U:S]\n", prog );
	printf("    USERNAME     (username of an ArrayDB account. Default: test)\n");
	printf("    PASSWORD     (password of an ArrayDB account. Default: test)\n");
	printf("    HOST:PORT    (ArrayDB database host and port. Default: 127.0.0.1:8888)\n");
	printf("    IERATIONS    (Number of query iterations. Default: 1)\n");
	printf("    CONCURRENCY  (Number of concurrent queries in each iteration. Default: 1)\n");
	printf("    SQLFILE      (Full path of file containing query statements.)\n");
	printf("    SHOWFLAG     (Whether to print query results: 1 for Yes, 0 for No. Default: 0)\n");
	printf("    SQLFILE      (Optional. File containting RQL commands.)\n");
	printf("    I:U:S        (Optional. Number of Inserts, Updates, Selects in each test unit.)\n");
	printf("\n");
	printf("    Note:  The database used in this program is: test\n");
	printf("           The table used in this program is:    jbench \n");
	printf("           Table jbench has schema:  key: uid char(16), value: addr char(32)\n");
	printf("\n");
}

// thread function
void  *threadTask( void *inp )
{
	TestPass *p = (TestPass*)inp;
	int  useRatio = p->useRatio; 
	if ( useRatio ) {
		return threadRatioTask( p );
	} else {
		return threadFileTask( p );
	}
}

// Execute commands from a file
void  *threadFileTask( TestPass *p )
{
	char line[1024];
	AbaxDataString fpath = p->fpath;
	AbaxDataString host = p->host;
	AbaxDataString port = p->port;
	AbaxDataString username = p->username;
	AbaxDataString passwd = p->passwd;
	AbaxDataString dbname = p->dbname;
	int isThread = p->isThread;
	int showflag = atoi( p->showflag.c_str() );

	FILE *fp = fopen( fpath.c_str(), "r" );
	if ( ! fp ) {
		printf("Error open [%s]\n", fpath.c_str() );
		if ( isThread ) {
			pthread_exit( NULL );
		} else {
			_exit( 0 );
		}
		return NULL;
	}

	int rc;
	JaguarCPPClient adb;

    if ( ! adb.connect( host.c_str(), atoi(port.c_str()), username.c_str(), passwd.c_str(), dbname.c_str(), NULL, 0 ) ) {
        printf( "Error connect to [%s:%s] [%s]\n", host.c_str(), port.c_str(), adb.error() );
        adb.close( );
		if ( isThread ) {
			pthread_exit( NULL );
		} else {
			_exit( 0 );
		}
        return NULL;
    }

	int len;
	memset( line, 0, 1024 );
	int cnt = 0;
	while ( NULL != ( fgets( line, 1024, fp )  ) ) {
		len = strlen( line );
		line[len-1] = '\0';
		rc = adb.query( line );
		if ( ! rc ) {
			printf("adbQuery Error %s\n", adb.error( ) );
			break;
		}

		while ( adb.reply() ) {
			if ( showflag ) {
				adb.printRow( stdout );
			}
		}
		if ( adb.hasError( ) ) {
			printf("adbReply Error: [%s]\n", adb.error( ) );
			break;
		}
		adb.freeResult();
		memset( line, 0, 1024 );
	}

	fclose( fp );
	adb.close( );

	if ( isThread ) {
		pthread_exit( NULL );
	} else {
		_exit( 0 );
	}
	
	return NULL;
}


// thread task according to command line  -r "i:u:s"
void  *threadRatioTask( TestPass *p )
{
	char line[1024];
	AbaxDataString host = p->host;
	AbaxDataString port = p->port;
	AbaxDataString username = p->username;
	AbaxDataString passwd = p->passwd;
	AbaxDataString dbname = p->dbname;
	AbaxDataString ratiostr = p->ratiostr;
	int isThread = p->isThread;
	int showflag = atoi( p->showflag.c_str() );

	int  insertNum = 0;
	int  updateNum = 0;
	int  selectNum = 0;
	parseRatio( ratiostr.c_str(), &insertNum, &updateNum, &selectNum );

	int rc;
	JaguarCPPClient adb;

    if ( ! adb.connect( host.c_str(), atoi(port.c_str()), username.c_str(), passwd.c_str(), dbname.c_str(), NULL, 0 ) ) {
        printf( "Error connect to [%s:%s] [%s]\n", host.c_str(), port.c_str(), adb.error() );
        adb.close( );
		if ( isThread ) {
			pthread_exit( NULL );
		} else {
			_exit( 0 );
		}
        return NULL;
    }

	int len;
	ratioWork( adb, p, insertNum, updateNum, selectNum, showflag );
	adb.close( );

	if ( isThread ) {
		pthread_exit( NULL );
	} else {
		_exit( 0 );
	}
	
	return NULL;
}

// Work on jobs according to numer of tasks:  insert:update:select
int ratioWork( JaguarCPPClient &adb, TestPass *tp, int insertNum, int updateNum, int selectNum, int showflag )
{
	int i, rc;
	char query[256];
	AbaxString key, value;
	int concurrency = tp->concurrency;

	time_t now = time(NULL) - (rand()%100000);

	// do inserts
	if ( concurrency > 1 ) { srand( now ); } else { srand(10); }

	for ( i = 0; i < insertNum; ++ i ) {
		key = AbaxString::randomValue(16);
		value = AbaxString::randomValue(32);
		sprintf( query, "insert into jbench (uid,addr ) values ( '%s','%s' ); ", key.c_str(), value.c_str() );
		rc = adb.query( query );
		if ( ! rc ) {
			printf("Error adbQuery (%s) [%s]\n", query, adb.error() );
			return 0;
		}
		while ( adb.reply( ) ) { }
		if ( adb.hasError( ) ) {
			printf("%s\n", adb.error( ) );
		}
		adb.freeResult( );
	}

	sprintf( query, "insert into jbench (uid,addr) values ( 'apple', 'SR' ); "  ); 
	adb.query(  query );
	while ( adb.reply( ) ) { }
	adb.freeResult( );

	sprintf( query, "insert into jbench (uid,addr) values ( 'orange', 'DV' ); "  ); 
	adb.query( query );
	while ( adb.reply( ) ) { }
	adb.freeResult( );

	sprintf( query, "insert into jbench (uid,addr) values ( 'banana', 'LA' ); "  ); 
	adb.query( query );
	while ( adb.reply( ) ) { }
	adb.freeResult( );

	sprintf( query, "insert into jbench (uid,addr) values ( 'cherry', 'SF' ); "  ); 
	adb.query( query );
	while ( adb.reply( ) ) { }
	adb.freeResult( );

	sprintf( query, "insert into jbench (uid,addr) values ( 'mango', 'WA' ); "  ); 
	adb.query( query );
	while ( adb.reply( ) ) { }
	adb.freeResult( );


	// do updates
	if ( concurrency > 1 ) { srand( now ); } else { srand(10); }
	for ( i = 0; i < updateNum; ++ i ) {
		key = AbaxString::randomValue(16);
		value = AbaxString::randomValue(32);
    	sprintf( query, "update jbench set addr='newvalue' where uid='%s'; ",  key.c_str() ); 
    	int rc = adb.query( query );
    	if ( ! rc ) {
    		printf("Error adbQuery (%s) [%s]\n", query, adb.error() );
    		return 0;
    	}
    	while ( adb.reply( ) ) { }
    	adb.freeResult( );
	}

	// do selects
	if ( concurrency > 1 ) { 
		if ( tp->keepTable ) {
			srand( 10 );
		} else {
			srand( now ); 
		}
	} else { srand(10); }

	for ( i = 0; i < selectNum; ++ i ) {
		key = AbaxString::randomValue(16);
		value = AbaxString::randomValue(32);
    	sprintf( query, "select * from jbench where uid = '%s'; ",  key.c_str() ); 
    	rc = adb.query( query );
    	if ( ! rc ) {
    		printf("Error adbQuery (%s) [%s]\n", query, adb.error() );
    		return 0;
    	}
    
    	while ( adb.reply( ) ) { 
    		if ( showflag ) {
    			adb.printRow( stdout );
    		}
    	}
    	adb.freeResult( );
	}
}


// str:  "10:2:50"
void parseRatio( const char *str, int *insertNum, int *updateNum, int *selectNum )
{
	*insertNum = 0;
	*updateNum = 0;
	*selectNum = 0;

	char *rs = strdup( str );
	char *p, *q;
	p = rs;
	while( *p != ':' && *p != '\0' ) ++p;
	if ( *p == '\0' ) { free( rs ); return; }

	*p = '\0';
	*insertNum = atoi( rs );

	++p;
	q = p;
	while( *p != ':' && *p != '\0' ) ++p;
	if ( *p == '\0' ) { free( rs ); return; }
	*p = '\0';
	*updateNum = atoi( q );

	++p;
	q = p;
	while( *p != '\0' ) ++p;
	*p = '\0';
	*selectNum = atoi( q );

	free( rs );
	return;

}

// drop and create table
int initTable(  TestPass *p, const AbaxDataString &table )
{
	char query[1024];
	AbaxDataString fpath = p->fpath;
	AbaxDataString host = p->host;
	AbaxDataString port = p->port;
	AbaxDataString username = p->username;
	AbaxDataString passwd = p->passwd;
	AbaxDataString dbname = p->dbname;

	JaguarCPPClient adb;

    if ( ! adb.connect( host.c_str(), atoi(port.c_str()), username.c_str(), passwd.c_str(), dbname.c_str(), NULL, 0 ) ) {
        printf( "Error connect to [%s:%s] [%s]\n", host.c_str(), port.c_str(), adb.error() );
        adb.close( );
        return 0;
    }

	sprintf( query, "create table jbench ( key: uid char(16), value: addr char(32) );" );
	adb.query( query );
	while ( adb.reply( ) ) { }
	adb.freeResult( );

    adb.close( );
	return 1;
}

// count how many commands in the file
int countFileLines ( const char *fpath )
{
	char line[1024];
	FILE *fp = fopen( fpath, "r" );
	if ( ! fp ) {
		printf("Error open [%s]\n", fpath );
		return 0;
	}
	int cnt = 0;
	while ( NULL != ( fgets( line, 1024, fp )  ) ) {
		++cnt;
	}
	fclose( fp );
	return cnt;
}
