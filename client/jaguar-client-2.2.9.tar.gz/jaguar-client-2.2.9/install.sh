#!/bin/bash

##########################################################################################
##  DataJaguar Inc.
##
##  Install script for Jaguar client 
##
##  ./install.sh     (You should execute this script on each host in your cluster)
##
##########################################################################################

/bin/mkdir -p $HOME/jaguar/bin
/bin/mkdir -p $HOME/jaguar/conf
/bin/mkdir -p $HOME/jaguar/data
/bin/mkdir -p $HOME/jaguar/index
/bin/mkdir -p $HOME/jaguar/log
/bin/mkdir -p $HOME/jaguar/doc
/bin/mkdir -p $HOME/jaguar/include
/bin/mkdir -p $HOME/jaguar/lib
/bin/mkdir -p $HOME/jaguar/tmp
/bin/mkdir -p $HOME/jaguar/backup

/bin/cp -f  jql jag jbench genrand rlwrap $HOME/jaguar/bin
/bin/cp -f include/*.h $HOME/jaguar/include
/bin/cp -f lib/*.a lib/*.so lib/*.jar lib/*.dll lib/jaguarnode.node $HOME/jaguar/lib
/bin/cp -f *.ini $HOME/jaguar/conf

/bin/cp -f  example.* README.* comp*.sh *.sql jcallinfo $HOME/jaguar/doc

echo "Successfully installed Jaguar client in $HOME/jaguar"

