#!/bin/bash

##########################################################################################
##
##  Install script for rdb client  (Revolutionary Database)
##
##########################################################################################

######## must be root or sudo user ###############
uid=$(id -u)
if ((uid!=0)); then
	echo "No files are installed into the system. root or sudo account is required."
	exit 1
else
	/bin/cp -f rdb rbench /usr/bin
	/bin/cp -f rdb.conf /etc/rdb.conf
	/bin/cp -f include/*.h /usr/include
	/bin/cp -f lib/lib*.a /usr/lib
fi


echo "Successfully installed ArrayDB client"



