#!/bin/bash

##########################################################################################
##
##  Install script for jaguar client 
##
##########################################################################################

/bin/mkdir -p $HOME/jaguar/bin
/bin/mkdir -p $HOME/jaguar/conf
/bin/mkdir -p $HOME/jaguar/data
/bin/mkdir -p $HOME/jaguar/log
/bin/mkdir -p $HOME/jaguar/doc
/bin/mkdir -p $HOME/jaguar/include
/bin/mkdir -p $HOME/jaguar/lib
/bin/mkdir -p $HOME/jaguar/tmp

/bin/cp -f jcli jag abench genrand rlwrap $HOME/jaguar/bin
/bin/cp -f include/*.h $HOME/jaguar/include
/bin/cp -f lib/lib*.a lib/lib*.so lib/*.jar $HOME/jaguar/lib

/bin/cp -f *.cc *.java README.* comp*.sh $HOME/jaguar/doc


echo "Successfully installed jaguar client in $HOME/jaguar"



