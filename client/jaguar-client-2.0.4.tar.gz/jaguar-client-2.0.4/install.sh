#!/bin/bash

##########################################################################################
##
##  Install script for $brand client 
##
##########################################################################################

brand=`cat brand.txt`

/bin/mkdir -p $HOME/$brand/bin
/bin/mkdir -p $HOME/$brand/conf
/bin/mkdir -p $HOME/$brand/data
/bin/mkdir -p $HOME/$brand/index
/bin/mkdir -p $HOME/$brand/log
/bin/mkdir -p $HOME/$brand/doc
/bin/mkdir -p $HOME/$brand/include
/bin/mkdir -p $HOME/$brand/lib
/bin/mkdir -p $HOME/$brand/tmp

/bin/cp -f  abench genrand rlwrap $HOME/$brand/bin
/bin/cp -f include/*.h $HOME/$brand/include
/bin/cp -f lib/lib*.a lib/lib*.so lib/*.jar $HOME/$brand/lib

/bin/cp -f *.cc *.java README.* comp*.sh $HOME/$brand/doc


echo "Successfully installed $brand client in $HOME/$brand"



