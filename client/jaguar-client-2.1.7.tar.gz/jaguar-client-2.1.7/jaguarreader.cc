#include <abax.h>
#include <JaguarReader.h>

int main( int argc, char *argv[] )
{
	AbaxDataString str;
	AbaxDataString tstr;
	int 	intcol;
	long 	longcol;
	float  	fcol;
	double 	dcol;
	int   	coltype;


	printf("Open DB=test  table=jbench ...\n");
	JaguarReader reader( "test", "jbench" );  // read whole table
	
	reader.begin();
	int cnt = 0;
	while ( reader.next() ) {
		coltype = reader.getType("uid");
		str = reader.getString( "uid" );  // uid is one column in table mytable

		// intcol = reader.getInt("prodtype");
		// tstr = reader.getTimeString("uptime");
		// fcol = reader.getFloat("fn");
		// dcol = reader.getDouble("dn");

		printf("type=[%d] str=[%s]\n", coltype,  str.c_str() );
		if ( cnt++ > 10 ) {
			break;
		}
	}
}


