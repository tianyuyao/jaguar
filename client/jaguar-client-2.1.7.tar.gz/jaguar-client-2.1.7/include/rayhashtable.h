#ifndef _RAY_HASH_H_
#define _RAY_HASH_H_

typedef struct ray_hash_t 
{
  struct HashNodeT **bucket;        /* array of hash nodes */
  int size;                           /* size of the array */
  int entries;                        /* number of entries in table */
  int downshift;                      /* shift cound, used in hash function */
  int mask;                           /* used to select bits for hashing */
  unsigned char empty;
} ray_hash_t;


void ray_hash_init(ray_hash_t *, int buckets);

// NULL is not found
char *ray_hash_lookup (const ray_hash_t *t, const char *key);

int ray_hash_insert (ray_hash_t *t, const char *key, const char *val );
int ray_hash_delete (ray_hash_t *t, const char * key);

int ray_hash_insert_int (ray_hash_t *t, int key, int val );
bool ray_hash_lookup_int (const ray_hash_t *t, int key, int *val );

int ray_hash_insert_str_int (ray_hash_t *t, const char *key, int val );
bool ray_hash_lookup_str_int (const ray_hash_t *t, const char *key, int *val );


void ray_hash_destroy(ray_hash_t *t);
void ray_hash_print(ray_hash_t *t);

#endif

