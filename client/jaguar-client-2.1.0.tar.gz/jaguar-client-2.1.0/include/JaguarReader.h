#ifndef _jaguar_reader_
#define _jaguar_reader_

#include <abax.h>

class ArrayDB;
class BinaryOperationNode;
class BinaryExpressionBuilder;
class RayRecord;
class OneColAttribute;
class AbaxBuffReader;
template <class K, class V> class AbaxHashMap;

#define TYPE_INT 10
#define TYPE_LONG 20
#define TYPE_FLOAT 30
#define TYPE_DOUBLE 40
#define TYPE_TIME 50
#define TYPE_STRING 60

class JaguarReader
{

  public:
		JaguarReader( const char *dbName, const char *tableName, const char *where=NULL );
		~JaguarReader(); 
		bool    begin();
		bool    next();

		// per row values
		AbaxDataString getString( const char *name );  // name can be a key field or value field
		int    getInt( const char *name );  // name can be a key field or value field
		long    getLong( const char *name );  // name can be a key field or value field
		float    getFloat( const char *name );  // name can be a key field or value field
		double    getDouble( const char *name );  // name can be a key field or value field
		AbaxDataString    getTimeString( const char *name );  // name can be a key field or value field

		// per table values
		int	    getType( const char *name );  // type of a column
		long    size() const;    // how many non-empty elements
		long    capacity() const;   // how many cells in the array
		int	    getFD();
		int     keyLength();
		int     valueLength();
		void	setConcurrent();

  protected:
  	ArrayDB *_arraydb;

	char *_buffer;
	AbaxBuffReader *_buffRead;

	// where parse tree pointer
	BinaryExpressionBuilder *_whereTree;
	BinaryOperationNode *_root;
	
	AbaxHashMap<AbaxString, abaxint> *_posmap;	
	OneColAttribute *_colsAttr;
	RayRecord *_record;
	const char *_dbName;
	const char *_tableName;
	int _KEYLEN;
	int _VALLEN;
	int _KEYVALLEN;
		
		AbaxDataString getOneField( const char *name );  // getOneField

};


#endif

