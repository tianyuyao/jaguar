#ifndef _abax_format_h_
#define _abax_format_h_

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

class AbaxFormat
{
	public:
		AbaxFormat() 
		{
			len = 0;
		}

		void setKeyFormat(const char *format=NULL) 
		{
			if ( format != NULL ) {
				parse( format );
			}
		}

		~AbaxFormat() 
		{
			if ( len > 0 ) {
				delete [] typearr;
				delete [] lenarr;
				delete [] separr;
			}
		}

		void print()
		{
			int i;

			printf("typearr: " );
			for ( i=0; i < len; ++i)
			{
				printf("%c ", typearr[i] );
			}
			printf("\n");

			printf("lenarr: " );
			for ( i=0; i < len; ++i)
			{
				printf("%d ", lenarr[i] );
			}
			printf("\n");

			printf("separr: " );
			for ( i=0; i < len; ++i)
			{
				printf("[%c] ", separr[i] );
			}
			printf("\n");

		}

	public:
		int  len;
		char *typearr;
		int  *lenarr;
		char *separr;

	private:
		void parse( const char *format ) 
		{
			// format:  "%s,%d|%s:%3d-%10s-%d,%4d%5s%8d%12s"
			const char *p;
			const char *beg;
			int i;


			// check empty format
			len = 0;
			if ( 0 == strcmp(format, "") || 0 == strcmp(format, "%")  ) {
				return;
			}

			// get len
			p = format;
			while( *p ) {
				if ( *p == '%' ) {
					++len;
				}
				++p;
			}

			if ( len < 1 ) return;

			typearr = new char[len];
			lenarr = new int[len];
			separr = new char[len];

			p = format;
			i = 0;
			while( *p ) {
				if ( *p == '%' ) {
					++p;   // 23d  or  1s  or s  or d
					beg = p;
					while ( isdigit( *p ) ) ++p;
					// p should be sep char now

					if ( beg == p ) {
						// no length
						lenarr[i] = 0;
					} else {
						lenarr[i] = atoi(beg);  // 23d gives 23  ;  3s --> 3
					}

					// *p should be d or s, if not, exit
					if ( *p == 's' || *p == 'd' ) {
						typearr[i] = *p;
					} else {
						printf("e2414 fatal error: format [%s] is invalid\n", format );
						exit(1);
					}

					if ( *(p+1) == '%' )  // %23d%   not sep
					{
						separr[i] = '\0';
					}
					else
					{
						separr[i] = *(p+1);  // %23d,
					}
					++i;
				}
				++p;
			}

		}
};

/********
int main( int argc, char *argv[] )
{
	// const char *fmt  = "%s,%d,%2s,%3d";
	char *fmt  = "%s|%d-%2s%3d:%4d%5s";
	if ( argc > 1 )
	{
		fmt = argv[1];
	}

	AbaxFormat f( fmt );
	printf("Format: [%s]\n",  fmt );
	f.print();
}
*********/

// int compare_string( const char *str1, const char *str2, const AbaxFormat &fmt );
template <class KType> int compareString( const KType &s1, const KType &s2,  const AbaxFormat &fmt );


template <class KType>
int compareString( const KType &s1, const KType &s2,  const AbaxFormat &fmt )
{
	// key1:  "abcd,100,andfdf"
	// key2:  "fdfhjj,10,hello"
	// key2:  "2344,310,hello"
	// key2:  "ssss310hello"
	if ( ! KType::isString() ) return 0;
	char *str1 = (char*)s1.addr(); 
	char *str2 = (char*)s2.addr(); 

	register int i, j;
	register char *p1, *p2;
	int len;
	char sep;
	unsigned long acc1, acc2;

	if ( NULL == str1 && NULL == str2 ) return 0;
	if ( NULL == str1 && NULL != str2 ) return -1;
	if ( NULL != str1 && NULL == str2 ) return 1;


	// fmt.lenarr  fmt.separr  fmt.typearr
	p1 = (char*)str1;
	p2 = (char*)str2;
	for ( i = 0; i < fmt.len; ++i )
	{
	 	len = fmt.lenarr[i];
	 	sep = fmt.separr[i];
		if ( fmt.typearr[i] == 's' ) 
		{
			j = 0;
    		while ( *p1 != sep && *p1 != '\0' && *p2 != sep && *p2 != '\0' ) 
			{
				if ( (int)*p1 < (int)*p2 ) return -1;
				if ( (int)*p1 > (int)*p2 ) return 1;
				++p1; ++p2; ++j;
				if ( len > 0 ) {
					if ( j >= len ) break;
				} 
			}

		} else {   // 'd'
			j = 0;
			acc1 = 0;
    		while ( *p1 != sep && *p1 != '\0' && isdigit(*p1) )  {
				acc1 *= 10;
				acc1 += *p1 - '0';
				++p1; ++j;
				if ( len > 0 ) {
					if ( j>=len) break;
				}
			}
			
			j = 0;
			acc2 = 0;
    		while ( *p2 != sep && *p2 != '\0' && isdigit(*p2) )  {
				acc2 *= 10;
				acc2 += *p2 - '0';
				++p2; ++j;
				if ( len > 0 ) {
					if ( j>=len) break;
				}
			}

			if ( acc1 < acc2 ) return -1;
			if ( acc1 > acc2 ) return 1;

		}

		if ( *p1 == sep || *p1 == '\0' ) {
			if ( *p2 != sep &&  *p2 != '\0' ) {
				return -1;
			}
		} else {
			if ( *p2 == sep || *p2 == '\0' ) {
				return 1;
			}
		}

		if ( *p1 == '\0' || *p2 == '\0' ) return 0;
		if ( sep ) { ++p1; ++p2; }

	}

	return 0;
}

#endif
