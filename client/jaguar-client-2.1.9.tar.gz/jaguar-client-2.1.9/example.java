import com.jaguar.jdbc.internal.jaguar.Jaguar;
import java.io.*;

public class example
{
    public static void main(String[] args)
    {
        // System.loadLibrary("JaguarClient");  // dll name is JaguarClient.dll
        // System.load("C:/msys1/home/Yue/commit/JaguarClient.dll");  // Windows
        System.loadLibrary("JaguarClient");  // need -Djava.library.path in Linux

        Jaguar client = new Jaguar();
        boolean rc = client.connect( "127.0.0.1", 8900, "admin", "jaguar", "test", "dummy", 0 );
		if ( ! rc ) {
           	System.out.println( "Connection error");
			System.exit(1);
		}
		
        rc = client.query( "select v1, uid, v3  from jbench limit 10;" );
        String val;
        while ( client.reply( false ) ) {
            val = client.getValue(  "uid" );
            System.out.println( val );

            val = client.getNthValue( 1 );
            System.out.println( val );

            val = client.getValue( "v1" );
            System.out.println( val );
            val = client.getNthValue( 2 );
            System.out.println( val );

            val = client.getValue( "v2" );
            System.out.println( val );
            val = client.getNthValue( 3 );
            System.out.println( val );

            val = client.getNthValue( 5 );
            System.out.println( "col 5: " + val );

            val = client.getNthValue( 0 );
            System.out.println( "col 0: " + val );

            val = client.getNthValue( -1 );
            System.out.println( "col -1: " + val );

        }

        if ( client.hasError( ) ) {
             String e = client.error( );
             System.out.println( e );
        }

        client.freeResult( ); 
        client.close();
    }
 }


