
LIBPATH=$JAGUAR_HOME/jaguar/lib

javac -cp $LIBPATH/jaguar-jdbc-2.0.jar  MetadataTest.java
java -Djava.library.path=$LIBPATH -cp $LIBPATH/jaguar-jdbc-2.0.jar:. MetadataTest

g++ -I$JAGUAR_HOME/jaguuar/include -o example example.cc $JAGUAR_HOME/jaguar/lib/libjaguar.a -lz
