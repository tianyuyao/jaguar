#include  <stdio.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <string.h>
#include <ArrayDBCPPClient.h>
//////////////////////////////////////////////////////////


int main( int argc, char *argv[] )
{
    const char username[]="test";
    const char passwd[]="test";
    const char dbname[]="test";
	const char  *unixSocket = NULL;
    short port = 8888;
	int rc;
    
	ArrayDBCPPClient adb;
    
    if ( ! adb.connect(  "127.0.0.1", port, username, passwd, dbname, unixSocket, 0 ) ) {
        printf( "Error connect\n");
        adb.close( );
        exit(1);
    }
    
	char  query[1024];
	memset( query, 0, 1024 );
	sprintf( query, "insert into user ( [uid='larryz', zip='99842'], [ city='danville', wechat='larryzx' ] )" );
    rc = adb.query( query ); 
	if ( ! rc ) {
        printf( "Error adbQuery insert\n");
        adb.close( );
        exit(1);
	}

	sprintf( query, "select * from user");
	rc = adb.query( query );
	if ( ! rc ) {
        printf( "Error adbQuery select [%s]\n", adb.error() );
        adb.close( );
        exit(1);
	}

    while ( adb.reply( ) ) {
		char *value = adb.getValue( "uid");
		printf("uid='%s' ", value );
		free( value );

		value = adb.getValue( "test.user.zip");
		printf("zip='%s' ", value );
		free( value );

		printf("\n"); 
    }

	if ( adb.hasError( ) ) {
		printf("Error: %s\n", adb.error( ) );
	}
	adb.freeResult( );

    adb.close( );
}

