#include <abax.h>
#include <JaguarReader.h>

int main( int argc, char *argv[] )
{
	AbaxDataString str;
	AbaxDataString tstr;
	int 	intcol;
	long 	longcol;
	float  	fcol;
	double 	dcol;
	int   	coltype;


	JaguarReader reader( "mydb", "mytable" );  // read whole table
	// JaguarReader reader( "test", "jbench" );  // read whole table
	// JaguarReader reader( "mydb", "mytable", "devid=10203 and uptime > '2015-12-10 01:01:30' );  // conditional read 
	
	reader.begin();
	while ( reader.next() ) {
		coltype = reader.getType("devid");
		str = reader.getString( "devid" );  // uid is one column in table mytable

		intcol = reader.getInt("prodtype");
		longcol = reader.getInt("serialNum");
		fcol = reader.getInt("power");
		dcol = reader.getInt("latitude");
		tstr = reader.getTimeString("uptime");

		// printf("str=[%s]\n", str.c_str() );
	}
}


