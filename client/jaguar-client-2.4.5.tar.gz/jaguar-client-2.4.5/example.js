var homedir=process.env.HOME;
var libname = homedir + "/jaguar/lib/jaguarnode";
const Jag = require( libname );
var jaguar = Jag.JaguarAPI();
jaguar.connect("127.0.0.1", 8900, "admin", "jaguar", "test");
jaguar.query("select * from jbench limit 10");
while(jaguar.reply()){
  jaguar.printRow();
}

jaguar.execute("create table nodejs ( key: uid char(16), value: addr char(32) )");
process.stdout.write("create table nodejs done\n");

jaguar.execute("insert into nodejs values ( k1, aaa1 )");
jaguar.execute("insert into nodejs values ( k2, aaa2 )");
jaguar.execute("insert into nodejs values ( k3, aaa3 )");
jaguar.execute("insert into nodejs values ( k4, aaa4 )");
jaguar.execute("delete from nodejs where uid=k4");
jaguar.execute("update nodejs set addr='newnew' where uid=k3");
process.stdout.write("insert delete update done\n");

jaguar.query("select * from nodejs");
while(jaguar.reply()){
  jaguar.printRow();
  var uid = jaguar.getValue("uid");
  var addr = jaguar.getValue("addr");
  process.stdout.write("uid: " + uid + "  addr: " + addr + "\n");
}
process.stdout.write("select done\n");

jaguar.execute("drop table nodejs");
process.stdout.write("drop table nodejs done\n");
