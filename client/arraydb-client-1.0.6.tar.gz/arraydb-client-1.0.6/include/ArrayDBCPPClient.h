#ifndef _adb_cpp_client_h_
#define _adb_cpp_client_h_

#define RAY_SOCK_MSG_HDR_LEN  10
#define RAY_ERR_MSG_LEN  256
#define RAY_MAX_NUM_KEYS  256
#define RAY_COL_MAX 512
#define RAY_NAME_MAX 64 
#define RAY_SESSIONID_MAX 32

typedef struct _RaySchemaProp {
	int 	offset;
	int 	length;
	char 	type;
	int  	sig;
} RaySchemaProp ;

struct  _RAYCLOCK
{
 	int  beginsec, beginmsec, beginusec;
   	int  endsec, endmsec, endusec;
};

struct  _ADB
{
    int 	socket;
	char  	errmsg[RAY_ERR_MSG_LEN];
	char  	dbname[RAY_NAME_MAX];
	char    *dbtablist;
	char    *query;
	char  	session[RAY_SESSIONID_MAX];
};
typedef struct _ADB  ADB;

struct _ADBROW
{
	int    retCode;
	char   *hdr;
	char   *data;
	char   type;
	char   op;
	int    samedb;   // selected tables all from one DB? if yes 1.
	
	char   *keyname[RAY_MAX_NUM_KEYS];
	RaySchemaProp prop[RAY_MAX_NUM_KEYS];
	int    numKeys;
	int    keyLength;
	int    valueLength;

	int    selectFieldFlag;
	char   selcols[RAY_COL_MAX][RAY_NAME_MAX];
	char 	*g_names[1024];
	char 	*g_values[1024];

	ADB    *adb;
	void   *etc;
};
typedef struct _ADBROW  ADBROW;


class ArrayDBCPPClient 
{
  public:
  	ArrayDBCPPClient();
	~ArrayDBCPPClient();
	void destroy();

	// 0: error  1: OK   adb->sock = socket() ....
	// send username and password to socket. Server verifies and sends authentication
	// info back from server. OK: 1  error: 0
	int connect( const char *ipaddress, unsigned int port, 
				const char *username, const char *passwd,
				const char *dbname, const char *unixSocket,
				unsigned long clientFlag );

    // send command to socket to server
    // 1: OK   0: error
    int query( const char *query );   // send query command over sock to server in adb object

    // server sends number of columns in the result over socket
    // client receives a row
    // 0: error or reaching the last record
    // 1: successful and having more records
    int reply( );

	// get session string
	const char *getSession();

	// set Op
	void setOp( char op );

	// get session string
	const char *getDatabase();

    // client receives a row
    int printRow( FILE *outf );

    // get n-th column in the row
    // NULL if not found; malloced char* if found, must be freed later
    char *getNthValue( int nth );

    // get error string from row
    // NULL if no error; Must be freeed after use
    char *error( ); 
    
    // row hasError?
    // 1: yes  0: no
    int hasError( );
    
    // free memory of row fields
    int freeRow( );
    
    // returns a pointer to char string as value for name
    // The buffer needs to be freed after use
    char *getValue( const char *name );
    
    // returns a integer
    // 1: if name exists in row; 0: if name does not exists in row
    int getInt(  const char *name, int *value );
    
    // returns a long
    // 1: if name exists in row; 0: if name does not exists in row
    int getLong(  const char *name, long *value );
    
    // returns a float value
    // 1: if name exists in row; 0: if name does not exists in row
    int getFloat(  const char *name, float *value );
    
    // returns a float value
    // 1: if name exists in row; 0: if name does not exists in row
    int getDouble(  const char *name, double *value );
    
    // return data buffer in row  and key/value length
    char *getData( int *keyLength, int *valueLength );
    
    // return data buffer in row  and key/value length
    char *getMessage( ); 
    
    // close and free up memory
    void close( );

	// client initializes the row
	int initRow();

    // count number of occurences of character ch in a string
    static int _strchrnum( const char *str, char ch );
    static int _rayrecv( int sock, char *hdr, int N );
    static int _raysend( int sock, const char *hdr, int N );


  protected:
  	ADB  	*_adb;
	ADBROW  *_row;

	// malloc ADB object, and return pointer to onject
	// return malloc( sizeof( ADB ) );
	// NULL for error
  	ADB     *_init();



    // Parse error msg from _END_[T=ddd|E=Error 1002 Syntax error in ...|X=...]
    // NULL: if no error
    // malloced string containing error message, must tbe freeed.
    char *_getField( const char * rowstr, char fieldToken );
    
    // client receives a row with all columns
    int _printRowAll( FILE *outf, char **retstr, int nth );
    
    // client receives a row with selected columns
    int _printSelCol( FILE *outf, char **retstr, int nth );
    
    // clean up memory in the row
    int _cleanupRow( );
    
    // free up data part only
    int _freeRowData( );
    
    
    // parse specific columns to the selcols 2D array
    int _parseCol( );
    
    // parse tokens from command
    int _parseTokens(const char *str,  const char *start, const char * end, char sep, char *result[], int *len );
    
    int _strInStr( const char *str, int len, const char *str2 );
    
    
    
    ////////// clock ///////////
    typedef struct _RAYCLOCK  RayClock;
    void rayClockStart( RayClock* clock );
    void rayClockStop( RayClock* clock );
    int  rayClockElapsed( RayClock* clock );
    
    //////////////// ray schema part ////////////////////////////
    int findKeyOffsetLength( const char *schemarec, const char *keyname, RaySchemaProp *prop );
    int findAllKeyProperty( const char *schemarec, char *keyname[], RaySchemaProp prop[], int *len );
    int findKeyLength( const char *schemarec ); 
    int findValueLength( const char *schemarec ); 

};


#endif

