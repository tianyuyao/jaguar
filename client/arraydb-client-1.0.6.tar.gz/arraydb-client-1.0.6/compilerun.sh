
LIBPATH=$HOME/arraydb/lib

javac -cp $LIBPATH/arraydb-jdbc-1.0.jar  MetadataTest.java
java -Djava.library.path=$LIBPATH -cp $LIBPATH/arraydb-jdbc-1.0.jar:. MetadataTest
