import com.arraydb.jdbc.ArrayDBDataSource;
import java.io.*;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

public class DataSourceTest 
{
	public static void main( String [] args ) {

		// load libArrayDBClient.so library
		System.loadLibrary("ArrayDBClient");

		DataSourceTest t = new DataSourceTest();

		try {
			t.testArrayDBDataSource();
		} catch ( SQLException e ) {
		}
	}

    public void testArrayDBDataSource() throws SQLException {
        DataSource ds = new ArrayDBDataSource("127.0.0.1", 8888, "test");  // host port database
        Connection connection = ds.getConnection("test", "test");  // username and password
		Statement statement = connection.createStatement();

		statement.executeUpdate("update mytable set m1='ssss' where uid='johndoe888';");
		ResultSet rs = statement.executeQuery("select * from mytable limit 10;");
		String val;
		String m1;
		while(rs.next()) {
			val = rs.getString("uid");
			m1 = rs.getString("m1");
			System.out.println( "uid: " + val + " m1: " + m1  );
		}
		rs.close(); // must close to free up memory
		statement.close();
		connection.close();
    }
}
