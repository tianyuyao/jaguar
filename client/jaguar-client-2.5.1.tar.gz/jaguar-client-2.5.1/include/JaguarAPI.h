#ifndef _jaguar_api_h_
#define _jaguar_api_h_

#include <stdio.h>


class JaguarCPPClient;

class JaguarAPI
{
  public:
  	JaguarAPI();
	~JaguarAPI();

	int connect( const char *ipaddress, unsigned int port, 
				const char *username, const char *passwd,
				const char *dbname, const char *unixSocket=NULL,
				unsigned long clientFlag=0 ); 

    // send DML command (not select) to socket to server
    // 1: OK   0: error
    int execute( const char *query ); 

    // send command to socket to server
    // 1: OK   0: error
    int query( const char *query, bool reply=true ); 

    // 0: error or reaching the last record
    // 1: successful and having more records
    int reply( bool headerOnly=false );

	// get session string
	const char *getSession();

	// get session string
	const char *getDatabase();

    // client receives a row
    int printRow();


    // get error string from row
    const char *error( ); 
    
    // row hasError?
    // 1: yes  0: no
    int hasError( );
    
	// free memory used by result
	int freeResult();

    // get n-th column in the row
    // NULL if not found; malloced char* if found, must be freed later
    char *getNthValue( int nth );

    // returns a pointer to char string as value for name
    // The buffer needs to be freed after use
    char *getValue( const char *name );
    
    // returns a integer
    // 1: if name exists in row; 0: if name does not exists in row
    int getInt(  const char *name, int *value );
    
    // returns a long
    // 1: if name exists in row; 0: if name does not exists in row
    int getLong(  const char *name, long *value );
    
    // returns a float value
    // 1: if name exists in row; 0: if name does not exists in row
    int getFloat(  const char *name, float *value );
    
    // returns a float value
    // 1: if name exists in row; 0: if name does not exists in row
    int getDouble(  const char *name, double *value );
    
    // return data buffer in row  and key/value length
    const char *getMessage( ); 

	// return data string in json format
	const char *jsonString( );

    // close and free up memory
    void close();

	int getColumnCount();
	char *getCatalogName( int col );
	char *getColumnClassName( int col );
	int getColumnDisplaySize( int col );
	char *getColumnLabel( int col );
	char *getColumnName( int col );
	int getColumnType( int col );
	char *getColumnTypeName( int col );
	int getScale( int col );
	char *getSchemaName( int col );
	char *getTableName( int col );
	bool isAutoIncrement( int col );
	bool isCaseSensitive( int col );
	bool isCurrency( int col );
	bool isDefinitelyWritable( int col );
	int  isNullable( int col );
	bool isReadOnly( int col );
	bool isSearchable( int col );
	bool isSigned( int col );


  protected:
	JaguarCPPClient *_jcli;

};


#endif

