#!/usr/bin/python

###########################################################################
##  Example program of Python for Jaguar
##
##  Copyright  DataJaguar Inc
##
###########################################################################
import jaguarpy

jag = jaguarpy.Jaguar()

rc = jag.connect( "192.168.2.200", 8900, "admin", "jaguar", "test", "", 0 )
print ("Connected to Jaguar server rc=%d " % ( rc ) )

rc = jag.query( "show tables" );
while  jag.reply():
	jag.printRow();

rc = jag.query( "select * from jbench limit 10" );
while jag.reply():
	jag.printRow();
	u=jag.getValue("uid")
	a=jag.getValue("addr")
	s = 'uid is ' + repr(u) + '  addr is ' + repr(a)
	print (s)
jag.freeResult()


rc = jag.query( "drop table t123;");
while jag.reply():
	jag.printRow();
jag.freeResult()

rc = jag.query( "create table t123 (key: uid char(32), value: dept char(32) ); " );
while jag.reply():
	jag.printRow();
jag.freeResult()

rc = jag.query( "insert into t123 values ( k1, v1 )");
rc = jag.query( "insert into t123 values ( k2, v1 )");
rc = jag.query( "insert into t123 values ( k3, v3 )");

rc = jag.query( "select * from t123 limit 10" );
while jag.reply():
	jag.printRow();
jag.freeResult()

rc = jag.execute( "drop table t123;", 0 );

jag = None
