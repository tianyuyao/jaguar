#include  <stdio.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <string.h>
///////////// include C header files /////////////////////
#ifdef __cplusplus
extern "C" {
#endif
#include <rdbclient.h>
#ifdef __cplusplus
}
#endif
//////////////////////////////////////////////////////////


int main( int argc, char *argv[] )
{
    const char username[]="test";
    const char passwd[]="test";
    const char dbname[]="test";
	const char  *unixSocket = NULL;
    short port = 8888;
    RDB *rdb;
	int rc;
    
    
    rdb = rdbInit();
    if ( rdb == NULL) {
        printf( "Error rdbInit, exit\n"); 
        exit(1);
    }
    
    if ( ! rdbConnect( rdb, "127.0.0.1", port, username, passwd, dbname, unixSocket, 0 ) ) {
        printf( "Error connect\n");
        rdbClose( rdb );
        exit(1);
    }
    
	char  query[1024];
	memset( query, 0, 1024 );
	sprintf( query, "insert into user ( [uid='larryz', zip='99842'], [ city='danville', wechat='larryzx' ] )" );
    rc = rdbQuery( rdb, query ); 
	if ( ! rc ) {
        printf( "Error rdbQuery insert\n");
        rdbClose( rdb );
        exit(1);
	}

	RDBROW     row; 
	sprintf( query, "select * from user");
	rc = rdbQuery( rdb, query );
	if ( ! rc ) {
        printf( "Error rdbQuery select [%s]\n", rdb->errmsg );
        rdbClose( rdb );
        exit(1);
	}

	rdbInitRow( rdb, &row );
    while ( rdbReply( &row ) ) {
		char *value = rdbGetValue( &row, "uid");
		printf("uid='%s' ", value );
		free( value );

		value = rdbGetValue(&row, "test.user.zip");
		printf("zip='%s' ", value );
		free( value );

		printf("\n"); 
    }

	if ( rdbHasError( &row ) ) {
		printf("Error: %s\n", rdbError( &row ) );
	}
	rdbFreeRow( &row );

    rdbClose( rdb );
}

