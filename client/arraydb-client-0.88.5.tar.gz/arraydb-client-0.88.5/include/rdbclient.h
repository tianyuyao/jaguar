#ifndef _rdb_client_h_
#define _rdb_client_h_

#define RAY_SOCK_MSG_HDR_LEN  10
#define RAY_ERR_MSG_LEN  256
#define RAY_MAX_NUM_KEYS  256
#define RAY_COL_MAX 512
#define RAY_NAME_MAX 64 

typedef struct _RaySchemaProp {
	int 	offset;
	int 	length;
	char 	type;
	int  	sig;
} RaySchemaProp ;

struct  _RDB
{
    int 	socket;
	char  	errmsg[RAY_ERR_MSG_LEN];
	char  	dbname[RAY_NAME_MAX];
	char    *dbtablist;
	char    *query;
};
typedef struct _RDB  RDB;

struct _RDBROW
{
	int    retCode;
	char   *hdr;
	char   *data;
	char   type;
	//ray_hash_t  hash1;
	//ray_hash_t  hash2;  // longname to short name hash
	char   op;
	int    samedb;   // selected tables all from one DB? if yes 1.
	
	char   *keyname[RAY_MAX_NUM_KEYS];
	RaySchemaProp prop[RAY_MAX_NUM_KEYS];
	int    numKeys;
	int    keyLength;
	int    valueLength;

	int    selectFieldFlag;
	char   selcols[RAY_COL_MAX][RAY_NAME_MAX];

	RDB    *rdb;
	void   *etc;
};
typedef struct _RDBROW  RDBROW;


// malloc RDB object, and return pointer to onject
// return malloc( sizeof( RDB ) );
// NULL for error
RDB * rdbInit();



// 0: error  1: OK   rdb->sock = socket() ....
// send username and password to socket. Server verifies and sends authentication
// info back from server. OK: 1  error: 0
int rdbConnect( RDB *rdb, const char *ipaddress, unsigned int port, 
				const char *username, const char *passwd,
				const char *dbname, const char *unixSocket,
				unsigned long clientFlag );


// send command to socket to server
// 1: OK   0: error
int rdbQuery( RDB *rdb, const char *query );   // send query command over sock to server in rdb object
// server sends number of columns in the result over socket


// client receives a row
// 0: error or reaching the last record
// 1: successful and having more records
int rdbReply( RDBROW* row );

// client initializes the row
int rdbInitRow( RDB *rdb, RDBROW* row );


// client receives a row
int rdbPrintRow( RDBROW* row, FILE *outf );


// get error string from row
// NULL if no error; Must be freeed after use
char * rdbError( RDBROW* row ); 

// row hasError?
// 1: yes  0: no
int rdbHasError( RDBROW* row );

// free memory of row fields
int rdbFreeRow( RDBROW* row );

// returns a pointer to char string as value for name
// The buffer needs to be freed after use
char *rdbGetValue( const RDBROW *row,  const char *name );

// returns a integer
// 1: if name exists in row; 0: if name does not exists in row
int rdbGetInt( const RDBROW *row,  const char *name, int *value );

// returns a long
// 1: if name exists in row; 0: if name does not exists in row
int rdbGetLong( const RDBROW *row,  const char *name, long *value );

// returns a float value
// 1: if name exists in row; 0: if name does not exists in row
int rdbGetFloat( const RDBROW *row,  const char *name, float *value );

// returns a float value
// 1: if name exists in row; 0: if name does not exists in row
int rdbGetDouble( const RDBROW *row,  const char *name, double *value );

// return data buffer in row  and key/value length
char *rdbGetData( const RDBROW *row, int *keyLength, int *valueLength );

// close and free up memory
void rdbClose( RDB *rdb );



///////////// The following are private functions of rdb ////////////////////////
// Parse error msg from _END_[T=ddd|E=Error 1002 Syntax error in ...|X=...]
// NULL: if no error
// malloced string containing error message, must tbe freeed.
char *_rdbGetField( const char * row, char fieldToken );

// build hash for name values
// int _rdbBuildHash( RDBROW *row );

// client receives a row with all columns
int _rdbPrintRowAll( RDBROW* row, FILE *outf );

// client receives a row with selected columns
int _rdbPrintSelCol( RDBROW* row, FILE *outf );

// clean up memory in the row
int _rdbCleanupRow( RDBROW *row );

// free up data part only
int _rdbFreeRowData( RDBROW* row );

// count number of occurences of character ch in a string
int _strchrnum( const char *str, char ch );

// parse specific columns to the selcols 2D array
int _rdbParseCol( RDBROW *row );

// parse tokens from command
int _rdbParseTokens(const char *str,  const char *start, const char * end, char sep, char *result[], int *len );

int _rdbStrInStr( const char *str, int len, const char *str2 );

int _rayrecv( int sock, char *hdr, int N );
int _raysend( int sock, const char *hdr, int N );


////////// clock ///////////
struct  _RAYCLOCK
{
	int  beginsec, beginmsec, beginusec;
	int  endsec, endmsec, endusec;
};
typedef struct _RAYCLOCK  RayClock;
void rayClockStart( RayClock* clock );
void rayClockStop( RayClock* clock );
int  rayClockElapsed( RayClock* clock );



//////////////// ray schema part ////////////////////////////

int findKeyOffsetLength( const char *schemarec, const char *keyname, RaySchemaProp *prop );
int findAllKeyProperty( const char *schemarec, char *keyname[], RaySchemaProp prop[], int *len );
int findKeyLength( const char *schemarec ); 
int findValueLength( const char *schemarec ); 

#endif

