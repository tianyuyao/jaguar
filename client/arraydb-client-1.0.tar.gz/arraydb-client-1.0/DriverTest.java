import com.arraydb.jdbc.ArrayDBDriver;
import com.arraydb.jdbc.internal.common.*;

import java.math.BigInteger;
import java.sql.*;
import java.util.List;
import java.io.*;
import java.math.BigDecimal;
import java.net.URL;

public class DriverTest {
    public static String host = "127.0.0.1";
    private Connection connection;

    public DriverTest() throws SQLException {
       connection = DriverManager.getConnection("jdbc:arraydb://127.0.0.1:8900/test", "test", "test" );
    }
    public void close() throws SQLException {
        connection.close();
    }
    public Connection getConnection() {
        return connection;
    }

    public void doQuery() throws SQLException{
        Statement stmt = connection.createStatement();

        try { stmt.executeUpdate("drop table t1"); } catch (Exception e) 
		{ System.out.println( e.getMessage() ); }

        stmt.executeUpdate("create table t1 ( key: id char(10), value: test char(20))");
        stmt.executeUpdate("insert into t1 ( [ id='111' ], [ test='fdfdfd1' ] ) ");
        stmt.executeUpdate("insert into t1 ( [ id='2222'], [ test='fdfdfd2' ] ) ");

        ResultSet rs = stmt.executeQuery("select * from t1");
		String k;
		String v;
        while ( rs.next() ) {
			k = rs.getString("id");
			v = rs.getString("test");
			System.out.println( "key: "+k + " value: " + v );
        }
		rs.close();

        rs = stmt.executeQuery("desc t1");
		String line;
        while ( rs.next() ) {
			line = rs.getString("");
			// line = rs.getString(null);
			System.out.println( line );
        }
		rs.close();
		stmt.close();
    }


 	public static void main( String [] args ) {
    	System.loadLibrary("ArrayDBClient");

		try {
			Class.forName("com.arraydb.jdbc.ArrayDBDriver");
		} catch ( ClassNotFoundException e ) {
			System.out.println( e.getMessage() );
		}

    	DriverTest t; 
		try {
    		t = new DriverTest();
			t.doQuery();
			t.close();
		} catch ( SQLException e ) {
			System.out.println( e.getMessage() );
		}
	}
}
