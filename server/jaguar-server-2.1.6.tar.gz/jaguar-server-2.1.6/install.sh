#!/bin/bash

##########################################################################################
##
##  Install Script 
##
##  ./install.sh           (for single host system)
##  ./install.sh cluster   (for cluster system, requires root or sudo)
##
##########################################################################################

brand=`cat brand.txt`
HOMEDIR=$HOME

cluster=$1
if [[ "x$cluster" = "xcluster" ]]; then
    userid=`id -u`
    if ((userid != 0 )); then
		echo "Please run this script as root or sudo"
		exit 1
	fi
	HOMEDIR=/home/jaguar
	./SetupUserAccount.sh

	### install glusterfs
	glusterversion=3.6.7
	glusterfile=glusterfs-${glusterversion}.tar.gz
	if ! type gluster; then
		/bin/cp -f $glusterfile /usr/local/src
		cd /usr/local/src
		tar zxf $glusterfile
		cd glusterfs-${glusterversion}
		./configure
		make; make install
		/etc/init.d/glusterd start
	fi
fi

/bin/mkdir -p $HOMEDIR/${brand}/bin
/bin/mkdir -p $HOMEDIR/${brand}/conf
/bin/mkdir -p $HOMEDIR/${brand}/data
/bin/mkdir -p $HOMEDIR/${brand}/index
/bin/mkdir -p $HOMEDIR/${brand}/log
/bin/mkdir -p $HOMEDIR/${brand}/doc
/bin/mkdir -p $HOMEDIR/${brand}/include
/bin/mkdir -p $HOMEDIR/${brand}/lib

######## copy files  ##############
/bin/cp -f jdb*  jadmin jag* job* jcli rlwrap *.sh $HOMEDIR/${brand}/bin

if [[ ! -f "$HOMEDIR/${brand}/conf/server.conf" ]]; then
	/bin/cp -f server.conf host.conf $HOMEDIR/${brand}/conf/
else
	/bin/cp -f server.conf $HOMEDIR/${brand}/conf/server.conf.new
	echo "Your exisiting configuration file $HOMEDIR/${brand}/conf/server.conf is not changed."
	echo "The new configuration file server.conf is saved as $HOMEDIR/${brand}/conf/server.conf.new"
fi
/bin/cp -f version.txt brand.txt $HOMEDIR/${brand}/conf
/bin/cp -f README.* $HOMEDIR/${brand}/doc

/bin/mkdir -p $HOMEDIR/${brand}/data/system
/bin/mkdir -p $HOMEDIR/${brand}/data/test
/bin/mkdir -p $HOMEDIR/${brand}/index/system
/bin/mkdir -p $HOMEDIR/${brand}/index/test
touch $HOMEDIR/${brand}/conf/license.txt

echo "Successfully installed ${brand} Server in $HOMEDIR/${brand}/"

