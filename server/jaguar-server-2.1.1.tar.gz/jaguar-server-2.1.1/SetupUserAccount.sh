#!/bin/bash

#############################################################################
##
##
## This script is for cluster set up. You must execute this as root
## script on all other hosts.
##
##
## Prerequisite: /home/$APPUSER/jaguar/conf/host.conf must have been
##               completed to contain all hosts in the cluster
##               $APPUSER is the use account that server will be run as.
##
##  Note: make sure $APPUSER has the same digital UID (8888) among all hosts.
##
#############################################################################

### require root or sudo
userid=`id -u`
if ((userid != 0 )); then
	echo "You must execute this script as root or sudo user"
	exit 1
fi


### create application user account
APPUSER=jaguar
/bin/mkdir -p /home/$APPUSER/jaguar
groupadd -g 8888 jaguar
useradd -u 8888 -g 8888 -d /home/$APPUSER -s /bin/bash $APPUSER
chown -R ${APPUSER}.${APPUSER} /home/$APPUSER

