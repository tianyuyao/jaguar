#!/bin/bash

##########################################################################################
##
##  Install script for rdb  (Revolutionary Database)
##
##########################################################################################

/bin/mkdir -p $HOME/arraydb/bin
/bin/mkdir -p $HOME/arraydb/conf
/bin/mkdir -p $HOME/arraydb/data
/bin/mkdir -p $HOME/arraydb/log
/bin/mkdir -p $HOME/arraydb/doc
/bin/mkdir -p $HOME/arraydb/include
/bin/mkdir -p $HOME/arraydb/lib

######## copy files  ##############
/bin/cp -f adbserv adbadmin adbstart adbstop adb adbcli aob* $HOME/arraydb/bin
if [[ ! -f "$HOME/arraydb/conf/arraydb.conf" ]]; then
	/bin/cp -f arraydb.conf $HOME/arraydb/conf
else
	/bin/cp -f arraydb.conf $HOME/arraydb/conf/arraydb.conf.new
	echo "Your exisiting configuration file $HOME/arraydb/conf/arraydb.conf is not changed."
	echo "The new configuration file arraydb.conf is saved as $HOME/arraydb/conf/arraydb.conf.new"
fi
/bin/cp -f version.txt $HOME/arraydb/conf
/bin/cp -f README.* $HOME/arraydb/doc

/bin/mkdir -p $HOME/arraydb/data/system
/bin/mkdir -p $HOME/arraydb/data/test

echo "Successfully installed ArrayDB Server in $HOME/arraydb/"

