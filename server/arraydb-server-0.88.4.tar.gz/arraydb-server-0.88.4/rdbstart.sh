#!/bin/bash

##########################################################################################
##
##  Startup script for rdb server  (Revolutionary Database)
##
##########################################################################################

######## must be root or sudo user ###############
un=`id -un` 
if [[ "x$un" != "xrdb" ]]; then 
	echo "You must be rdb user (or sudo to rdb) to run the rdbstart.sh script"
	exit 1
fi

rdbhome=`grep RDB_HOME /etc/rdb.conf |grep -v '#' | cut -d'=' -f2|tr -d ' '`
if [[ "x$rdbhome" = "x" ]]; then
	echo "Error: RDB_HOME is not set in /etc/rdb.conf"
	exit 1
fi

cd $rdbhome/system/log
/usr/bin/rdbserv > $rdbhome/system/log/rdbserv.log 2>&1 &
