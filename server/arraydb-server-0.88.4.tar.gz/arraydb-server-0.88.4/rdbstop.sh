#!/bin/bash

##########################################################################################
##
##  Stop script for rdb server  (Revolutionary Database)
##
##########################################################################################

######## must be root or sudo user ###############
un=`id -un` 
if [[ "x$un" != "xrdb" ]]; then 
	echo "You must be rdb user (or sudo to rdb) to run the rdbstart.sh script"
	exit 1
fi

rdbhome=`grep RDB_HOME /etc/rdb.conf |grep -v '#' | cut -d'=' -f2|tr -d ' '`
if [[ "x$rdbhome" = "x" ]]; then
	echo "Error: RDB_HOME is not set in /etc/rdb.conf"
	exit 1
fi

if [[ ! -f $rdbhome/system/rdbserv.pid ]]; then
	echo "rdbserv is not running"
	exit 1
fi

pid=`cat $rdbhome/system/rdbserv.pid`
kill -s SIGINT $pid
sleep 5
rpid=`/bin/ps aux|grep rdbserv|grep -v grep|awk '{print $2}'`
if [[ "x$rpid" != "x" ]]; then
	kill -s SIGINT $rpid
fi

