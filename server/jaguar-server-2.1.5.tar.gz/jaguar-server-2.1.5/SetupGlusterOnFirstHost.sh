#!/bin/bash

#############################################################################
##
##
## This script is for cluster set up. You must execute this as root
## script only on the first host in /home/$APPUSER/jaguar/conf/host.conf 
##
## Script for first-time setting up GlusterFS enviroment 
##
## Prerequisite: /home/$APPUSER/jaguar/conf/host.conf must have been
##               completed to contain all hosts in the cluster
##               $APPUSER is the use account that the server will be run as.
##
##  Note: make sure $APPUSER has the same digital UID among all hosts.
##
#############################################################################

dryrun=$1
if [[ "x$dryrun" = "x" ]]; then
	dryrun="no"
else
	dryrun="yes"
fi

### requires root or sudo
if [[ $dryrun = "no" ]]; then
    userid=`id -u`
    if ((userid != 0 )); then
    	echo "You must execute this script as root or sudo user"
    	exit 1
    fi
fi


### You can modify the user account that Jaguar will be run as
APPUSER=jaguar


### initialization
APPHOME=/home/$APPUSER/jaguar
((stripes=0))
((replicas=0))
allbricks=" "


######### read host info ######################################
ips=`hostname -I`
echo "Reading file $APPHOME/conf/host.conf ..."
allbricks=" "
((firstline=1))
while read line
do
	###  host  mirror1 mirror2
	echo "$line"
	((replicas=0))
	for brick in $line; do
		allbricks="$allbricks $brick "
		((replicas=replicas+1))
	done

	((stripes=stripes+1))
	if ((firstline==1)); then
		((firstline=0))
	else 
		if ((oldreplicas != replicas )); then
			echo "Error line on $line in file $APPHOME/conf/host.conf  exit "
			return 1
		fi
	fi

	((oldreplicas=replicas))
done < $APPHOME/conf/host.conf



#### stop the volume first
if [[ $dryrun != "yes" ]]; then
	killall -9 jdbserv
	echo "Do you want to delete all Jaguar data? [y/n](n) "
	read ans
	if [[ "x$ans" = "xy" ]]; then
		/bin/rm -rf /mnt/JaguarVolume/jaguar
	fi
	umount -l /mnt/JaguarVolume 2>/dev/null
	echo y | gluster volume stop JaguarVolume force  > /dev/null 2>&1
	echo y | gluster volume delete JaguarVolume
else
	echo "gluster volume stop JaguarVolume force"
	echo gluster volume delete JaguarVolume
fi

### peer probe all other hosts
myhost=`hostname`
((first=1))
while read line; do
	for hostbrick in $line; do
		if ((first!=1)); then
			host=`echo $hostbrick|awk -F: '{print $1}'`
			if [[ "x$host" = "x" ]]; then
				echo "Error in $line in $APPHOME/conf/host.conf"
				echo "Brick must be in ip:/dir format"
				exit 1
			fi
			echo "gluster peer probe $host"
			if [[ $dryrun != "yes" ]]; then
				gluster peer probe $host
			fi
		else
			BRICKDIR=`echo $hostbrick|awk -F: '{print $2}'`
			if [[ "x$BRICKDIR" = "x" ]]; then
				echo "Error in $line in $APPHOME/conf/host.conf"
				echo "Brick must be in ip:/dir format"
				exit 1
			fi

			if [[ $dryrun != "yes" ]]; then
				/bin/mkdir -p $BRICKDIR
				/bin/chmod 1777 $BRICKDIR
			else 
				echo /bin/mkdir -p $BRICKDIR
				echo /bin/chmod 1777 $BRICKDIR
			fi
		fi
	done

	if ((first=1)); then
		((first=0))
	fi

done < $APPHOME/conf/host.conf

### perpare parameters
echo "replicas=$replicas"
echo "stripes=$stripes"
if ((replicas>1)); then
	REPLICAS="replica $replicas"
else
	REPLICAS=""
fi


######## make gluster volume
if [[ $dryrun != "yes" ]]; then
    gluster volume create JaguarVolume \
    stripe $stripes $REPLICAS \
    transport tcp \
    $allbricks \
    force

    ### start volume
	stripe=`grep STRIPE_BLOCK_SIZE $APPHOME/conf/server.conf|grep -v '#'|cut -d'=' -f2`
	stripemb="64MB"
	if [[ "x$stripe" != "x" ]]; then
		stripemb="${stripe}MB"
	fi

    gluster volume start JaguarVolume
    gluster volume set JaguarVolume cluster.stripe-block-size $stripemb
    gluster volume set JaguarVolume nfs.disable  ON
else
    echo "gluster volume create JaguarVolume stripe $stripes $REPLICAS transport tcp $allbricks force"
fi


if [[ $dryrun = "yes" ]]; then
	echo umount /mnt/JaguarVolume
	echo /bin/mkdir -p /mnt/JaguarVolume
	echo mount -t glusterfs $myhost:/JaguarVolume /mnt/JaguarVolume
	echo /bin/mkdir -p /mnt/JaguarVolume/jaguar
	echo gluster volume status JaguarVolume 
	echo "ln -s /mnt/JaguarVolume/jaguar  $APPHOME"
	exit 0
fi

### mount locally
if [[ ! -d "/mnt/JaguarVolume" ]]; then
	/bin/mkdir -p /mnt/JaguarVolume
fi

echo "mount -t glusterfs $myhost:/JaguarVolume /mnt/JaguarVolume"
mount -t glusterfs $myhost:/JaguarVolume /mnt/JaguarVolume
if (($?==0)); then
    echo "mount -t glusterfs $myhost:/JaguarVolume /mnt/JaguarVolume OK"
    df -h
else
    echo "mount -t glusterfs $myhost:/JaguarVolume /mnt/JaguarVolume failed, exit"
    exit 1
fi

if grep -q JaguarVolume /etc/fstab; then
	echo "JaguarVolume is already in /etc/fstab"
else 
	echo "Add entry in /etc/fstab"
	echo "$myhost:/JaguarVolume /mnt/JaguarVolume  glusterfs defaults,noatime,_netdev 0 0" >> /etc/fstab
fi


### Jaguar data directory
echo /bin/mkdir -p /mnt/JaguarVolume/jaguar
/bin/mkdir -p /mnt/JaguarVolume/jaguar
if [[ ! -L "/home/$APPUSER/jaguar" ]]; then
	cd /home/$APPUSER
    echo /bin/cp -R /home/$APPUSER/jaguar/* /mnt/JaguarVolume/jaguar/
    /bin/cp -R /home/$APPUSER/jaguar/* /mnt/JaguarVolume/jaguar/
    /bin/mv -f /home/$APPUSER/jaguar /home/$APPUSER/jaguar.old
    chown -R ${APPUSER}.${APPUSER} /mnt/JaguarVolume/jaguar
    ln -s /mnt/JaguarVolume/jaguar  $APPHOME
fi


### show status of the volume
gluster volume status JaguarVolume 

