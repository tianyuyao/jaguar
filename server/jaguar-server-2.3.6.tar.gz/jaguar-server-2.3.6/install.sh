#!/bin/bash

##########################################################################################
##  DataJaguar Inc.
##
##  Jaguar Server Installation Script 
##
##  ./install.sh   (You should install Jaguar on each host in your cluster)
##
##########################################################################################

/bin/mkdir -p $HOME/jaguar/bin
/bin/mkdir -p $HOME/jaguar/conf
/bin/mkdir -p $HOME/jaguar/data
/bin/mkdir -p $HOME/jaguar/index
/bin/mkdir -p $HOME/jaguar/log
/bin/mkdir -p $HOME/jaguar/doc
/bin/mkdir -p $HOME/jaguar/include
/bin/mkdir -p $HOME/jaguar/lib
/bin/mkdir -p $HOME/jaguar/backup

######## copy files  ##############
/bin/cp -f jag* jql rlwrap *.sh $HOME/jaguar/bin

if [[ ! -f "$HOME/jaguar/conf/server.conf" ]]; then
	/bin/cp -f server.conf host.conf $HOME/jaguar/conf/
else
	/bin/cp -f server.conf $HOME/jaguar/conf/server.conf.new
	echo "Your exisiting configuration file $HOME/jaguar/conf/server.conf is not changed."
	echo "The new configuration file server.conf is saved as $HOME/jaguar/conf/server.conf.new"
fi
/bin/cp -f version.txt $HOME/jaguar/conf
/bin/cp -f README.* $HOME/jaguar/doc

/bin/mkdir -p $HOME/jaguar/data/system
/bin/mkdir -p $HOME/jaguar/data/test
/bin/mkdir -p $HOME/jaguar/index/system
/bin/mkdir -p $HOME/jaguar/index/test
touch $HOME/jaguar/conf/license.txt

echo "Successfully installed Jaguar Server in $HOME/jaguar/"
echo "Please install the same package on all the servers in your cluster."
echo "Also, conf/server.conf and conf/server.conf must be in synch among all servers."

