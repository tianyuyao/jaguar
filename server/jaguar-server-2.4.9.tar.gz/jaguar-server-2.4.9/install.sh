#!/bin/bash

##########################################################################################
##  DataJaguar Inc.
##
##  Jaguar Server Installation Script 
##
##  ./install.sh   (You should install Jaguar on each host in your cluster)
##
##########################################################################################

### users can change this to a different directory
export JAGUAR_HOME=$HOME

/bin/mkdir -p $JAGUAR_HOME/jaguar/bin
/bin/mkdir -p $JAGUAR_HOME/jaguar/conf
/bin/mkdir -p $JAGUAR_HOME/jaguar/data
/bin/mkdir -p $JAGUAR_HOME/jaguar/index
/bin/mkdir -p $JAGUAR_HOME/jaguar/log
/bin/mkdir -p $JAGUAR_HOME/jaguar/doc
/bin/mkdir -p $JAGUAR_HOME/jaguar/include
/bin/mkdir -p $JAGUAR_HOME/jaguar/lib
/bin/mkdir -p $JAGUAR_HOME/jaguar/backup

######## copy files  ##############
/bin/cp -f jag* jql rlwrap *.sh $JAGUAR_HOME/jaguar/bin

if [[ ! -f "$JAGUAR_HOME/jaguar/conf/server.conf" ]]; then
	/bin/cp -f server.conf host.conf $JAGUAR_HOME/jaguar/conf/
else
	/bin/cp -f server.conf $JAGUAR_HOME/jaguar/conf/server.conf.new
	echo "Your exisiting configuration file $JAGUAR_HOME/jaguar/conf/server.conf is not changed."
	echo "The new configuration file server.conf is saved as $JAGUAR_HOME/jaguar/conf/server.conf.new"
fi
/bin/cp -f version.txt $JAGUAR_HOME/jaguar/conf
/bin/cp -f README.* $JAGUAR_HOME/jaguar/doc

/bin/mkdir -p $JAGUAR_HOME/jaguar/data/system
/bin/mkdir -p $JAGUAR_HOME/jaguar/data/test
/bin/mkdir -p $JAGUAR_HOME/jaguar/index/system
/bin/mkdir -p $JAGUAR_HOME/jaguar/index/test
touch $JAGUAR_HOME/jaguar/conf/license.txt

echo "Successfully installed Jaguar Server in $JAGUAR_HOME/jaguar/"
echo "Please install the same package on all the servers in your cluster."
echo "Also, conf/server.conf and conf/server.conf must be in synch among all servers."

