#!/bin/bash

##########################################################################################
##
##  Install script for rdb  (Revolutionary Database)
##
##########################################################################################

/bin/mkdir -p $HOME/arraydb/bin
/bin/mkdir -p $HOME/arraydb/conf
/bin/mkdir -p $HOME/arraydb/data
/bin/mkdir -p $HOME/arraydb/log
/bin/mkdir -p $HOME/arraydb/doc
/bin/mkdir -p $HOME/arraydb/include
/bin/mkdir -p $HOME/arraydb/lib

######## copy files  ##############
/bin/cp -f rdbserv rdbadmin rdbstart.sh rdbstop.sh rdb $HOME/arraydb/bin
/bin/cp -f rdb.conf $HOME/arraydb/conf

/bin/mkdir -p $HOME/arraydb/data/system
/bin/mkdir -p $HOME/arraydb/data/test

echo "Successfully installed ArrayDB Server in $HOME/arraydb/"

