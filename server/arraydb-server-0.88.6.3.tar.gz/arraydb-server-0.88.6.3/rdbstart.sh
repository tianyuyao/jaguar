#!/bin/bash

##########################################################################################
##
##  Startup script for rdb server  (Revolutionary Database)
##
##########################################################################################

/bin/mkdir -p $HOME/arraydb/bin
/bin/mkdir -p $HOME/arraydb/conf
/bin/mkdir -p $HOME/arraydb/data
/bin/mkdir -p $HOME/arraydb/log
/bin/mkdir -p $HOME/arraydb/doc
/bin/mkdir -p $HOME/arraydb/include
/bin/mkdir -p $HOME/arraydb/lib


cd $HOME/arraydb/log
$HOME/arraydb/bin/rdbserv > $HOME/arraydb/log/dbserv.log 2>&1 &
