#!/bin/bash

##########################################################################################
##
##  Stop script for rdb server  (Revolutionary Database)
##
##########################################################################################

if [[ ! -f $HOME/arraydb/data/system/rdbserv.pid ]]; then
	echo "rdbserv is not running"
	exit 1
fi

pid=`cat $HOME/arraydb/data/system/rdbserv.pid`
kill -s SIGINT $pid
sleep 5
rpid=`/bin/ps aux|grep rdbserv|grep $USER|grep -v grep|awk '{print $2}'`
if [[ "x$rpid" != "x" ]]; then
	kill -s SIGINT $rpid 2>/dev/null
fi

