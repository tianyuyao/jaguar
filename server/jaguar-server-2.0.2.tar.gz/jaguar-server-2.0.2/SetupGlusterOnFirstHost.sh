#!/bin/bash

#############################################################################
##
##   Exeray Inc.
##
## This script is for Jaguar cluster set up. You must execute this as root
## script only on the first host in /home/$JAGUARUSER/jaguar/conf/host.conf 
##
## Script for first-time setting up GlusterFS enviroment 
##
## Prerequisite: /home/$JAGUARUSER/jaguar/conf/host.conf must have been
##               completed to contain all hosts in the cluster
##               $JAGUARUSER is the use account that Jaguar will be run as.
##
##  Note: make sure $JAGUARUSER has the same digital UID among all hosts.
##
#############################################################################


### requires root or sudo
userid=`id -u`
if ((userid != 0 )); then
	echo "You must execute this script as root or sudo user"
	exit 1
fi


### You can modify the user account that Jaguar will be run as
JAGUARUSER=jaguar


### initialization
BRICK=/home/GlusterBrick
JAGUARHOME=/home/$JAGUARUSER/jaguar
((stripes=0))
((replicas=0))
allhosts=" "
if [[ ! -d "$BRICK" ]]; then
	/bin/mkdir -p $BRICK
	/bin/chmod 1777 $BRICK
fi


######### read host info ######################################
echo "Reading file $JAGUARHOME/conf/host.conf ..."
allhosts=" "
((firstline=1))
while read line
do
	###  host  mirror1 mirror2
	echo "$line"
	((replicas=0))
	for host in $line; do
		allhosts="$allhosts $host:$BRICK "
		((replicas=replicas+1))
	done

	((stripes=stripes+1))
	if ((firstline==1)); then
		((firstline=0))
	else 
		if ((oldreplicas != replicas )); then
			echo "Error line on $line in file $JAGUARHOME/conf/host.conf  exit "
			return 1
		fi
	fi

	((oldreplicas=replicas))
done < $JAGUARHOME/conf/host.conf



#### stop the volume first
gluster volume stop JaguarVolume force 


### peer probe all other hosts
myhost=`hostname`
((first=1))
while read line; do
	for host in $line; do
		if ((first!=1)); then
			echo "gluster peer probe $host"
			gluster peer probe $host
		else
			((first=0))
		fi
	done
done < $JAGUARHOME/conf/host.conf

### perpare parameters
echo "replicas=$replicas"
echo "stripes=$stripes"
if ((replicas>1)); then
	REPLICAS="replica $replicas"
else
	REPLICAS=""
fi


######## make gluster volume
gluster volume create JaguarVolume \
stripe $stripes $REPLICAS \
transport tcp \
$allhosts \
force

### start volume
gluster volume start JaguarVolume
gluster volume set JaguarVolume cluster.stripe-block-size 64MB


### mount locally
umount /mnt/JaguarVolume
if [[ ! -d "/mnt/JaguarVolume" ]]; then
	/bin/mkdir -p /mnt/JaguarVolume
fi
mount -t glusterfs $myhost:/JaguarVolume /mnt/JaguarVolume
if grep -q JaguarVolume /etc/fstab; then
	echo "JaguarVolume is already in /etc/fstab"
else 
	echo "Add entry in /etc/fstab"
	echo "$myhost:/JaguarVolume /mnt/JaguarVolume  glusterfs defaults,noatime,_netdev 0 0" >> /etc/fstab
fi


### Jaguar data directory
/bin/mv -f $JAGUARHOME/data $JAGUARHOME/data.old
/bin/mkdir -p /mnt/JaguarVolume/data
chown ${JAGUARUSER}.${JAGUARUSER} /mnt/JaguarVolume/data
ln -s /mnt/JaguarVolume/data  $JAGUARHOME/data


### show status of the volume
gluster volume status JaguarVolume 

