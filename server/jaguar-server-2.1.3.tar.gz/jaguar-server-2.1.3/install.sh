#!/bin/bash

##########################################################################################
##
##  Install Script 
##
##########################################################################################

brand=`cat brand.txt`

/bin/mkdir -p $HOME/${brand}/bin
/bin/mkdir -p $HOME/${brand}/conf
/bin/mkdir -p $HOME/${brand}/data
/bin/mkdir -p $HOME/${brand}/index
/bin/mkdir -p $HOME/${brand}/log
/bin/mkdir -p $HOME/${brand}/doc
/bin/mkdir -p $HOME/${brand}/include
/bin/mkdir -p $HOME/${brand}/lib

######## copy files  ##############
/bin/cp -f jdb*  jadmin jag* job* jcli rlwrap *.sh $HOME/${brand}/bin

if [[ ! -f "$HOME/${brand}/conf/server.conf" ]]; then
	/bin/cp -f server.conf host.conf $HOME/${brand}/conf/
else
	/bin/cp -f server.conf $HOME/${brand}/conf/server.conf.new
	echo "Your exisiting configuration file $HOME/${brand}/conf/server.conf is not changed."
	echo "The new configuration file server.conf is saved as $HOME/${brand}/conf/server.conf.new"
fi
/bin/cp -f version.txt brand.txt $HOME/${brand}/conf
/bin/cp -f README.* $HOME/${brand}/doc

/bin/mkdir -p $HOME/${brand}/data/system
/bin/mkdir -p $HOME/${brand}/data/test
/bin/mkdir -p $HOME/${brand}/index/system
/bin/mkdir -p $HOME/${brand}/index/test
touch $HOME/${brand}/conf/license.txt

echo "Successfully installed ${brand} Server in $HOME/${brand}/"

