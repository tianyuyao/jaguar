#!/bin/bash

#############################################################################
##
##
## This script is for cluster set up. You must execute this as root
## script only on the first host in /home/$APPUSER/jaguar/conf/host.conf 
##
## Script for first-time setting up GlusterFS enviroment 
##
## Prerequisite: /home/$APPUSER/jaguar/conf/host.conf must have been
##               completed to contain all hosts in the cluster
##               $APPUSER is the use account that the server will be run as.
##
##  Note: make sure $APPUSER has the same digital UID among all hosts.
##
#############################################################################


### requires root or sudo
userid=`id -u`
if ((userid != 0 )); then
	echo "You must execute this script as root or sudo user"
	exit 1
fi


### You can modify the user account that Jaguar will be run as
APPUSER=jaguar


### initialization
BRICK=/home/GlusterBrick
APPHOME=/home/$APPUSER/jaguar
((stripes=0))
((replicas=0))
allhosts=" "
if [[ ! -d "$BRICK" ]]; then
	/bin/mkdir -p $BRICK
	/bin/chmod 1777 $BRICK
fi


######### read host info ######################################
echo "Reading file $APPHOME/conf/host.conf ..."
allhosts=" "
((firstline=1))
while read line
do
	###  host  mirror1 mirror2
	echo "$line"
	((replicas=0))
	for host in $line; do
		allhosts="$allhosts $host:$BRICK "
		((replicas=replicas+1))
	done

	((stripes=stripes+1))
	if ((firstline==1)); then
		((firstline=0))
	else 
		if ((oldreplicas != replicas )); then
			echo "Error line on $line in file $APPHOME/conf/host.conf  exit "
			return 1
		fi
	fi

	((oldreplicas=replicas))
done < $APPHOME/conf/host.conf



#### stop the volume first
echo y | gluster volume stop JaguarVolume force  > /dev/null 2>&1
gluster volume delete JaguarVolume

### peer probe all other hosts
myhost=`hostname`
((first=1))
while read line; do
	for host in $line; do
		if ((first!=1)); then
			echo "gluster peer probe $host"
			gluster peer probe $host
		else
			((first=0))
		fi
	done
done < $APPHOME/conf/host.conf

### perpare parameters
echo "replicas=$replicas"
echo "stripes=$stripes"
if ((replicas>1)); then
	REPLICAS="replica $replicas"
else
	REPLICAS=""
fi


######## make gluster volume
gluster volume create JaguarVolume \
stripe $stripes $REPLICAS \
transport tcp \
$allhosts \
force

### start volume
gluster volume start JaguarVolume
gluster volume set JaguarVolume cluster.stripe-block-size 64MB
gluster volume set JaguarVolume nfs.disable  ON



### mount locally
umount /mnt/JaguarVolume
if [[ ! -d "/mnt/JaguarVolume" ]]; then
	/bin/mkdir -p /mnt/JaguarVolume
fi
mount -t glusterfs $myhost:/JaguarVolume /mnt/JaguarVolume
if grep -q JaguarVolume /etc/fstab; then
	echo "JaguarVolume is already in /etc/fstab"
else 
	echo "Add entry in /etc/fstab"
	echo "$myhost:/JaguarVolume /mnt/JaguarVolume  glusterfs defaults,noatime,_netdev 0 0" >> /etc/fstab
fi


### Jaguar data directory
/bin/mv -f /home/$APPUSER/jaguar /home/$APPUSER/jaguar.old
/bin/mkdir -p /mnt/JaguarVolume/jaguar
chown ${APPUSER}.${APPUSER} /mnt/JaguarVolume/jaguar
ln -s /mnt/JaguarVolume/jaguar  $APPHOME


### show status of the volume
gluster volume status JaguarVolume 

