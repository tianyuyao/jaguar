#!/bin/bash

##########################################################################################
##
##  Install script for rdb  (Revolutionary Database)
##
##########################################################################################

######## must be root or sudo user ###############
un=`id -un`
if [[ "x$un" != "xroot" ]]; then 
	echo "You must be root or sudo user to run the install.sh script"
	exit 1
fi

rdbhome=`grep RDB_HOME rdb.conf |grep -v '#' | cut -d'=' -f2`
if [[ "x$rdbhome" = "x" ]]; then
	echo "Error: RDB_HOME is not set in rdb.conf"
	exit 1
fi

######## create user rdb ##################
id rdb > /dev/null 2>&1
((rc=$?))
if ((rc!=0)); then
	groupadd rdb
	mkdir -p $rdbhome >/dev/null 2>&1
	useradd -g rdb  -d $rdbhome rdb >/dev/null 2>&1
else
	echo "User rdb exists, OK ..."
fi


######## copy files  ##############
/bin/cp -f rdbserv rdbadmin rdbstart.sh rdbstop.sh rdb /usr/bin/
/bin/cp -f rdb.conf /etc/rdb.conf

/bin/mkdir -p $rdbhome/system/log
/bin/mkdir -p $rdbhome/test
/bin/chown -R rdb.rdb $rdbhome

echo "Successfully installed ArrayDB Server"

