#!/bin/bash

#############################################################################
##
##
## This script is for cluster set up. You must execute this as root
## script on all other hosts.
##
##
## Prerequisite: /home/$APPUSER/jaguar/conf/host.conf must have been
##               completed to contain all hosts in the cluster
##               $APPUSER is the use account that the server will be run as.
##
##  Note: make sure $APPUSER has the same digital UID among all hosts.
##
#############################################################################

### require root or sudo
userid=`id -u`
if ((userid != 0 )); then
	echo "You must execute this script as root or sudo user"
	exit 1
fi


### create application user account
APPUSER=jaguar


### make directories
BRICK=/home/GlusterBrick
APPHOME=/home/$APPUSER/jaguar
if [[ ! -d "$BRICK" ]]; then
	/bin/mkdir -p $BRICK
	/bin/chmod 1777 $BRICK
fi

if [[ ! -d "/mnt/JaguarVolume" ]]; then
	/bin/mkdir -p /mnt/JaguarVolume
fi


### mount  the volume
umount /mnt/JaguarVolume
mount -t glusterfs $myhost:/JaguarVolume /mnt/JaguarVolume
if grep -q JaguarVolume /etc/fstab; then
	echo "JaguarVolume is already in /etc/fstab"
else 
	echo "Add entry in /etc/fstab"
	echo "$myhost:/JaguarVolume /mnt/JaguarVolume  glusterfs defaults,noatime,_netdev 0 0" >> /etc/fstab
fi


### set up application data directory
/bin/mv -f $APPHOME/jaguar $APPHOME/jaguar.old
/bin/mkdir -p /mnt/JaguarVolume/jaguar
chown ${APPUSER}.${APPUSER} /mnt/JaguarVolume/jaguar
ln -s /mnt/JaguarVolume/jaguar  $APPHOME/jaguar

