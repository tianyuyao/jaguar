#!/bin/bash

##########################################################################################
##
##  Install script for jaguar 
##
##########################################################################################

/bin/mkdir -p $HOME/jaguar/bin
/bin/mkdir -p $HOME/jaguar/conf
/bin/mkdir -p $HOME/jaguar/data
/bin/mkdir -p $HOME/jaguar/log
/bin/mkdir -p $HOME/jaguar/doc
/bin/mkdir -p $HOME/jaguar/include
/bin/mkdir -p $HOME/jaguar/lib

######## copy files  ##############
/bin/cp -f jdb*  jadmin jag* job* jcli rlwrap *.sh  $HOME/jaguar/bin

if [[ ! -f "$HOME/jaguar/conf/jaguar.conf" ]]; then
	/bin/cp -f jaguar.conf host.conf $HOME/jaguar/conf
else
	/bin/cp -f jaguar.conf $HOME/jaguar/conf/jaguar.conf.new
	echo "Your exisiting configuration file $HOME/jaguar/conf/jaguar.conf is not changed."
	echo "The new configuration file jaguar.conf is saved as $HOME/jaguar/conf/jaguar.conf.new"
fi
/bin/cp -f version.txt $HOME/jaguar/conf
/bin/cp -f README.* $HOME/jaguar/doc

/bin/mkdir -p $HOME/jaguar/data/system
/bin/mkdir -p $HOME/jaguar/data/test

echo "Successfully installed jaguar Server in $HOME/jaguar/"

