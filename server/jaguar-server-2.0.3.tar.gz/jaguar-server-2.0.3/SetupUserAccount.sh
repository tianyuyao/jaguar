#!/bin/bash

#############################################################################
##
##   Exeray Inc.
##
## This script is for Jaguar cluster set up. You must execute this as root
## script on all other hosts.
##
##
## Prerequisite: /home/$JAGUARUSER/jaguar/conf/host.conf must have been
##               completed to contain all hosts in the cluster
##               $JAGUARUSER is the use account that Jaguar will be run as.
##
##  Note: make sure $JAGUARUSER has the same digital UID (8888) among all hosts.
##
#############################################################################

### require root or sudo
userid=`id -u`
if ((userid != 0 )); then
	echo "You must execute this script as root or sudo user"
	exit 1
fi


### create application user account
JAGUARUSER=jaguar
/bin/mkdir -p /home/$JAGUARUSER/jaguar
groupadd -g 8888 jaguar
useradd -u 8888 -g 8888 -d /home/$JAGUARUSER -s /bin/bash $JAGUARUSER
chown -R ${JAGUARUSER}.${JAGUARUSER} /home/$JAGUARUSER

