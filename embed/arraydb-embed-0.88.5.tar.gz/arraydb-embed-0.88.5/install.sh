#!/bin/bash

##########################################################################################
##
##  Install script for embedded arraydb
##
##########################################################################################

######## must be root or sudo user ###############
uid=$(id -u)
if ((uid!=0)); then
	echo "No files are installed in system directories. root or sudo account is required."
	exit 1
else
	/bin/cp -f *.h /usr/include
	/bin/cp -f lib*.a /usr/lib
fi

echo "Successfully installed embedded ArrayDB"





