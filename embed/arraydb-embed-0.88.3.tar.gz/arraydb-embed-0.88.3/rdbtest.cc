#include <abax.h>
#include <ArrayDB.h>

char *randomString( int size );
void usage( const char *prog )
{
	printf("\n");
	printf("Usage:  %s  N   [concurrent]\n", prog );
	printf("   N            (The number of data items to be inserted)\n");
	printf("   concurrent   (1: allows multi-thread concurrent operations; 0: No multi-thread support. Default: 0 )\n");
	printf("\n");
	printf("Examples:\n");
	printf("%s  10000\n", prog );
	printf("%s  10000  1\n", prog );
	printf("\n");
}

int main( int argc, char *argv[] )
{
	char *key, *value, *getvalue;
	int   keyLength = 16;
	int   valueLength = 16;
	int   max = 100;
	int   cnt;
	int   i;
	bool  rc;
	int   concurrent = 0;

	if ( argc > 1 ) {
		max = atoi( argv[1] );
		if ( argc > 2 ) {
			concurrent = atoi( argv[2] );
		}
	} else {
		usage( argv[0] );
		exit(1);
	}

	time_t now = time(NULL);
	char   tbuf[64];
	sprintf( tbuf, ctime(&now) );
	tbuf[strlen(tbuf)-1] = '\0';

	printf("TESTBEGIN\n");
	printf("prog=%s time=%ld date=%s user=%s items=%d concurrent=%d\n", 
			argv[0], now, tbuf, getenv("USER"), max, concurrent );

	unlink( "ArrayDBTest.rdb" );
	unlink( "ArrayDBTesthash.rdb" );

	ArrayDB rdb( "ArrayDBTest", keyLength, valueLength );
	if ( concurrent ) {
		rdb.setConcurrent();
	}

	AbaxClock clock;
	long iops;

	AbaxMemory mem;
	mem.start();

	// test insert
	srand( 100 );
	clock.start();
	cnt = 0;
	for ( i = 0; i < max; ++i ) {
		key = randomString( keyLength );
		value = randomString( valueLength );
		rc = rdb.insert( key, value );
		if ( rc ) { ++cnt; }
		free( key );
		free( value );
	}
	clock.stop();
	iops = 1000* (cnt/ clock.elapsed());
	printf("Successfully insert()   %d records in %d milliseconds  IOPS=%d  size()=%d\n", 
			cnt, clock.elapsed(), iops, rdb.size() );
	fflush( stdout );
	mem.stop();
	int memused = mem.used();


	// test exist
	srand( 100 );
	clock.start();
	cnt = 0;
	for ( i = 0; i < max; ++i ) {
		key = randomString( keyLength );
		value = randomString( valueLength );
		rc = rdb.exist( key );
		if ( rc ) { ++cnt; }
		free( key );
		free( value );
	}
	clock.stop();
	iops = 1000*( cnt/ clock.elapsed() );
	printf("Successfully exist()    %d records in %d milliseconds  IOPS=%d\n", cnt, clock.elapsed(), iops );
	fflush( stdout );

	// test getValue
	srand( 100 );
	clock.start();
	cnt = 0;
	for ( i = 0; i < max; ++i ) {
		key = randomString( keyLength );
		value = randomString( valueLength );
		getvalue = rdb.getValue( key );
		if ( getvalue ) { 
			++cnt; 
			free( getvalue );
		}
		free( key );
		free( value );
	}
	clock.stop();
	iops = 1000*( cnt/ clock.elapsed() );
	printf("Successfully getValue() %d records in %d milliseconds  IOPS=%d\n", cnt, clock.elapsed(), iops );
	fflush( stdout );


	// test setValue
	srand( 100 );
	clock.start();
	cnt = 0;
	for ( i = 0; i < max; ++i ) {
		key = randomString( keyLength );
		value = randomString( valueLength );
		rc = rdb.setValue( key, "newvalue" );
		if ( rc ) { 
			++cnt; 
		}
		free( key );
		free( value );
	}
	clock.stop();
	iops = 1000*( cnt/ clock.elapsed() );
	printf("Successfully setValue() %d records in %d milliseconds  IOPS=%d\n", cnt, clock.elapsed(), iops );
	fflush( stdout );


	// index scan
	int j;
	clock.start();
	cnt = 0;
	int fd = rdb.fileDescriptor();
	int len = rdb.capacity();
	int  kvlen = keyLength+valueLength;
	int NUM = 100;
	int  block = NUM * kvlen;
	char *buf = (char*)malloc( block );
	for ( i = 0; i < len/NUM; ++i ) {
		read(fd, buf, block ); 
		for ( j = 0; j < NUM; ++j ) {
			if ( buf[j*kvlen] != '\0' ) {
				++ cnt;
			}
		}
	}
	clock.stop();
	free( buf );
	if ( clock.elapsed() ) {
		iops = 1000*( cnt/ clock.elapsed() );
		printf("Successfully scanned    %d records in %d milliseconds  IOPS=%d\n", cnt, clock.elapsed(), iops );
	} else {
		iops = cnt*(1000*1000/clock.elapsedusec());
		printf("Successfully scanned    %d records in %d microseconds  IOPS=%d\n", cnt, clock.elapsedusec(), iops );
	}
	fflush( stdout );


	// test remove
	srand( 100 );
	clock.start();
	cnt = 0;
	for ( i = 0; i < max; ++i ) {
		key = randomString( keyLength );
		value = randomString( valueLength );
		rc = rdb.remove( key );
		if ( rc ) { 
			++cnt; 
		}
		free( key );
		free( value );
	}
	clock.stop();
	iops = 1000*( cnt/ clock.elapsed() );
	printf("Successfully remove()   %d records in %d milliseconds  IOPS=%d  size()=%d\n", 
			cnt, clock.elapsed(), iops, rdb.size() );
	printf("Memory used:            %d MB\n", memused );
	printf("TESTEND\n");

	printf("\n");
	fflush( stdout );
	return 0;
}



char *randomString( int size )
{
    int i, j;
    static char cset[] = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"; // 62 total
    char *mem = (char*)malloc(size+1);
    for ( i = 0; i< size; i++) {
        j = rand() % 62;
        mem[i] = cset[j];
    }
    mem[i] = '\0';
    return mem;
}

