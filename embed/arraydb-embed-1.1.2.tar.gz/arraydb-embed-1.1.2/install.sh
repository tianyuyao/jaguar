#!/bin/bash

##########################################################################################
##
##  Install script for embedded arraydb
##
##########################################################################################

/bin/mkdir -p $HOME/arraydb/bin
/bin/mkdir -p $HOME/arraydb/conf
/bin/mkdir -p $HOME/arraydb/data
/bin/mkdir -p $HOME/arraydb/log
/bin/mkdir -p $HOME/arraydb/doc
/bin/mkdir -p $HOME/arraydb/include
/bin/mkdir -p $HOME/arraydb/lib


######## must be root or sudo user ###############
/bin/cp -f *.h $HOME/arraydb/include
/bin/cp -f lib*.a $HOME/arraydb/lib
/bin/cp -f adbtest $HOME/arraydb/bin

echo "Successfully installed embedded ArrayDB in $HOME/arraydb"





