///////////////////////////////////////////////////////////////////////////////////////
//
//  Exeray Inc, All Rights Reserved   www.exeray.com
//
//  THIS SOFTWARE IS PROVIDED BY EXERAY INC "AS IS" AND ANY EXPRESS OR IMPLIED
//  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
//  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
//  EVENT SHALL EXERAY INC BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
//  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
//  OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
//  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
//  STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
//  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////////////////
#ifndef _arraydb_h_
#define _arraydb_h_

class AbaxDBPair;
template <class K> class AbaxDiskArray;

class ArrayDB
{
	public:

		ArrayDB( const char *fpath, int keyLength, int valueLength );
		~ArrayDB();

		bool 	insert( const char *key, const char *value ) ;
		bool 	exist( const char *key ); 
		char 	*getValue( const char *key ); 
		bool 	setValue( const char *key, const char *value );
		bool 	remove( const char *key );
		void	setConcurrent();

		long    size() const; 
		long    capacity() const; 
		void    drop();
		void 	print() const;
		int	    fileDescriptor();


	protected:
		AbaxDiskArray<AbaxDBPair>  *_diskArray;
		int    _KEYLEN;
		int    _VALLEN;
		bool   _concurrent;

};

#endif
